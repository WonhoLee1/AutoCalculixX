#ifndef Gbod_hxx
#define Gbod_hxx

/************** Class Gbod *****************/
class Gbod
{
  public:
    
    Gbod(char * namei);
    
    char * getName();
    
    void addFace(TopoDS_Face * f);
    
    TopoDS_Shell *  joinFaces(BRep_Builder * builder);   
    
  private:
    char name[9];
    vector<TopoDS_Face*> myBoundingBox;
    TopoDS_Shell shell;
};
/************ Class Gbod END ***************/

#endif