#ifndef Surface_hxx
#define Surface_hxx

/************ Class Surface ****************/
class Surface
{  
  public: 
    Surface(char * namei);
    
    void setSurf(Handle(Geom_Surface) aSurf);
    
    Handle(Geom_Surface) getSurf();
    
    char * getName();
  
  private:
    Handle(Geom_Surface) mySurf;
    char name[9];
};

/********** Class Surface End **************/

#endif