#ifndef Seqa_hxx
#define Seqa_hxx

using namespace std;

/************* Class Seqa *****************/
class Seqa
{
  public:
    Seqa(char * namei);
    
    void addPoint(Point* p);
    
    vector<Point*> * getPointVec();
    
    char * getName();
    
    int * getSize();
    
    
  private:
    char name[9];
    int size;
    vector<Point*> myPoints;
};
/************* Class Seqa End **************/

#endif