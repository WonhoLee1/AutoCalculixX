#ifndef Point_hxx
#define Point_hxx

/************* Class Point ****************/
class Point
{
  public:
    Point(const char * namei);
     
    char * getName();
    
    void setX(double xi);
    void setY(double yi);
    void setZ(double zi);
    
    double * getX();
    double * getY();
    double * getZ();
    
  private:
    char name[9];
    double x,y,z;
};
/************ Class Point End *************/

#endif