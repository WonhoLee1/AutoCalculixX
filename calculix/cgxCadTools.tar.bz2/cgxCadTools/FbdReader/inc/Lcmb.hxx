#ifndef Lcmb_hxx
#define Lcmb_hxx


/************** Class Lcmb *****************/
class Lcmb : public Element2d
{
  public: 
    Lcmb(char * namei);
    
    void makeEdge();
      
    void addElement2d(Element2d * el, bool forward);
    
  private:
    vector<Element2d*> myLines;
    vector<bool> orientation;
};
/************ Class Lcmb End ***************/

#endif