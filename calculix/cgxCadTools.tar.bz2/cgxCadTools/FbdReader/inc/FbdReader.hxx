#ifdef globalDefine
  #define EXTERN
#else
  #define EXTERN extern
#endif

//OpenCascade libraries 
#include <TopoDS.hxx>
#include <TopoDS_Shape.hxx> 
#include <TopoDS_Compound.hxx>
#include <TopoDS_CompSolid.hxx>
#include <TopoDS_Solid.hxx>
#include <TopoDS_Shell.hxx>
#include <TopoDS_Wire.hxx>
#include <TopoDS_Face.hxx>
#include <TopoDS_Edge.hxx>
#include <TopoDS_Vertex.hxx>
#include <TopoDS_Builder.hxx>

#include <TopExp_Explorer.hxx>
#include <TopExp.hxx>
#include <TopTools_ListOfShape.hxx>

#include <BRep_Builder.hxx>

#include <BRepBuilderAPI_MakeEdge.hxx>
#include <BRepBuilderAPI_MakeWire.hxx>
#include <BRepBuilderAPI_MakeFace.hxx>
#include <BRepBuilderAPI_MakeShell.hxx>
#include <BRepBuilderAPI_MakeSolid.hxx>
#include <BRepBuilderAPI_Sewing.hxx>

#include <BRepTools_WireExplorer.hxx>

#include <IGESControl_Writer.hxx>
#include "STEPControl_Writer.hxx"
#include <IGESControl_Controller.hxx> 
#include <Interface_Static.hxx>
#include "BRepGProp.hxx"
#include "GProp_GProps.hxx"

#include <Geom_Curve.hxx>
#include <Geom_Line.hxx>
#include <Geom_BSplineCurve.hxx>
#include <Geom_Circle.hxx>
#include <Geom_Ellipse.hxx>
#include <Geom_Hyperbola.hxx>
#include <Geom_Parabola.hxx>
#include <Geom_BezierCurve.hxx>
#include <Geom_TrimmedCurve.hxx>
#include <Geom_OffsetCurve.hxx>

#include <Geom_Surface.hxx>
#include <Geom_BSplineSurface.hxx>
#include <Geom_Plane.hxx>
#include <Geom_CylindricalSurface.hxx>
#include <Geom_SphericalSurface.hxx>
#include <Geom_ToroidalSurface.hxx>
#include <Geom_ConicalSurface.hxx>

#include <gp_Pnt.hxx>
#include <NCollection_Array1.hxx>
#include <TColStd_Array1OfInteger.hxx>
#include <TColStd_Array1OfReal.hxx>
#include <TColStd_Array2OfReal.hxx>
#include <TColgp_Array1OfPnt.hxx>
#include <TColgp_Array2OfPnt.hxx>

#include <Standard_Transient.hxx>
#include <Standard.hxx>

#include <GeomPlate_CurveConstraint.hxx>
#include <GeomAdaptor_Curve.hxx>
#include <GeomAdaptor_HCurve.hxx>
#include <GeomPlate_CurveConstraint.hxx>
#include <GeomPlate_BuildPlateSurface.hxx>
#include <GeomPlate_MakeApprox.hxx>
#include <GeomConvert_CompCurveToBSplineCurve.hxx>
#include <Geom_TrimmedCurve.hxx>
#include <GeomConvert.hxx>
#include <GeomFill_BSplineCurves.hxx>
#include <GeomFill_Coons.hxx>

#include <GeomAPI_PointsToBSpline.hxx>
#include <GeomAPI_Interpolate.hxx>
#include <TColgp_HArray1OfPnt.hxx>

#include <ShapeFix.hxx>
#include <ShapeFix_Shape.hxx>
#include <ShapeFix_Wireframe.hxx>
#include <ShapeFix_Edge.hxx>

#include <ShapeUpgrade_RemoveInternalWires.hxx>
#include <ShapeUpgrade_UnifySameDomain.hxx>
#include <GCPnts_AbscissaPoint.hxx>

#include <ShapeBuild_ReShape.hxx>

//C++ Includes
#include <iostream>
#include <string>
#include <vector>
#include <math.h>

//Topology Classes
#include <Util.hxx>
#include <Point.hxx>
#include <Seqa.hxx>
#include <Surface.hxx>
#include <Element2d.hxx>
#include <Line.hxx>
#include <Arc.hxx>
#include <Spline.hxx>
#include <Lcmb.hxx>
#include <Gsur.hxx>
#include <Gbod.hxx>
#include <BSplineCurve.hxx>

using namespace std;

//Lists countaining the cgx entities
EXTERN vector <Point*> pointVec;
EXTERN vector <Seqa*> seqaVec;
EXTERN vector <Element2d*> elem2dVec;
EXTERN vector <Lcmb*> lcmbVec;
EXTERN vector <Gsur*> gsurVec;
EXTERN vector <Surface*> nurbsVec;
EXTERN vector <Gbod*> gbodVec;

//User inputs when calling main function
EXTERN bool useSeqaPoints,wireFrame,usePia;
EXTERN double splineTolerance;

EXTERN ifstream input;

EXTERN BRep_Builder myBuilder;
EXTERN BRep_Builder WireFrameBuilder;
EXTERN TopoDS_Wire TestWire;

bool parseFBD(char * filename);
void saveStep(TopoDS_Shape * shape,char * name);
void startScreen();
int pointGetIndex(const char * name);

//Interpolatin funktion form cgx CalculiX
double intpol3(double *x, double *y, int n, double x0, int *method, double s, int iopt );
