#ifndef NurbsUtil_hxx
#define NurbsUtil_hxx

typedef struct 
{
  double * cX;
  double * cY;
  double * cZ;
  double * weights;
  double * uKnt;
  double * vKnt;
  int nUPol, nVPol, nUKnt,nVKnt;
  int uDeg,vDeg;
}BSplineSurface;

typedef struct 
{
  double * cX;
  double * cY;
  double * cZ;
  double * w;
  double * k;
  int nPol, nKnt;
  int deg;
}NurbsCurve;


void rotateBSpline(double *p1, double *p2, NurbsCurve * myCurve ,BSplineSurface * mySurf);

double wik(int k,int i,double *u,double x);

double deBoor(int k, int i, double * u ,double x);

void calculateBSpline(double * pnt, NurbsCurve * myCurve,double u, bool rational);

void piaFitting(double pCloud [][3],int nPnt,NurbsCurve * fitCurve, int deg, double tolerance);

 Handle_Geom_BSplineCurve compCurve(vector<Handle(Geom_Curve)> *curveList, vector<int*> * curveDivisions);


#endif 
