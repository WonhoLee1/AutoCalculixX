#ifndef Util_hxx
#define Util_hxx

/*********************************************************/
/*  Vektorbetrag: C =  Vektor(B)-Vektor(A) == Vector(AB) */
/*********************************************************/
void vl_result( double *A, double *B, double *C );

/*********************************************************/
/*    Vektormultiplikation: C = A x B                    */
/*********************************************************/
void vl_prod( double *A, double *B, double *C );

/*********************************************************/
/*    Scalar Product: C = A o B                   	 */
/*********************************************************/
void vl_sprod( double *A, double *B, double *C );

/*********************************************************/
/*         Vector(B)=Vektor(A)/|A|                       */
/*********************************************************/
double vl_norm( double *A, double *C );

/* *******************************************************/
/*      laenge von Vektor a                              */
/* *******************************************************/
double vl_betrag(double *a);

/**********************************************************/
/* Vektormultiplikation:scalar(C) =  Vector(A)*Vektor(B) */
/**********************************************************/
void vl_scal( double *A, double *B, double *C );

/**********************************************************/
/* Vektormultiplikation: vektor(C) =  scalar(A)*Vektor(B) */
/**********************************************************/
void vl_mult( double *A, double *B, double *C );

/**********************************************************/
/*    Vektoraddition: C =  Vektor(B)+Vektor(A)            */
/**********************************************************/
void vl_add( double *A, double *B, double *C );

/**********************************************************/
/* Coordinate transformation	: A = M__ * P + t_ 	  */
/**********************************************************/
void vl_trans(double M [][3],double * t, double * P, double * A);

#endif