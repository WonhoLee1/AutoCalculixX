#ifndef Element2d_hxx
#define Element2d_hxx

/*********** Class Element2d ***************/
/*************** Abstract ******************/
class Element2d
{
  public:
    virtual void makeEdge() = 0; 
    
    char * getName();

    Handle_Geom_Curve getCurve();
    
    void setCurve(Handle_Geom_Curve c);
    
    TopoDS_Wire * getWire();
    
    TopoDS_Edge * getEdge();
    
    void setDiv(int d);
    
    int * getDiv();
    
  protected:
      char name[9];
      Handle(Geom_Curve) curve;
      TopoDS_Edge myEdge;
      TopoDS_Wire myWire;
      int div;
};
/*********** Class Element2d End ***********/

#endif