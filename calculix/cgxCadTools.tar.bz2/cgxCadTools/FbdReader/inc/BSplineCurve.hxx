#ifndef BSplineCurve_hxx
#define BSplineCurve_hxx

/********** Class BSplineCurve **************/
class BSplineCurve : public Element2d
{
  public:
    BSplineCurve(char * namei);
    
    void makeEdge();
};
/******* Class BSplineCurve END *************/

#endif