#ifndef Gsur_hxx
#define Gsur_hxx

/************** Class Gsur *****************/
class Gsur
{
  public: 
    Gsur(char * namei);
    
    void addWire(TopoDS_Wire * w, bool forward, int * div); 
    
    void constructBoundary();
    
    char * getName();
    
    void setSurf(Handle(Geom_Surface) aSurf);
    
    void composeFace();
    
    void setBlend(bool b);
    
    TopoDS_Face * getFace();
    
    void prepareConstraints();
    
    void fillSurface();
    
    void setFree(bool f);

    bool getFree();
    
  private:
    char name[9];
    vector<TopoDS_Wire> boundary;
    vector<TopoDS_Wire> myWire;
    vector<bool> wireUsed;
    Handle(Geom_Surface) mySurf;
    TopoDS_Face myFace;
    bool blend;
    vector<Handle(Geom_BSplineCurve)> constraints; 
    vector<int*> divisions;
    int nConstraint;
    bool freeFace;
};
/************ Class Gsur End ***************/

#endif