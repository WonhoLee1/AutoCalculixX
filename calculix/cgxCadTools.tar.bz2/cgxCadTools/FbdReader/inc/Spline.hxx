#ifndef Spline_hxx
#define Spline_hxx

/************* Class Spline ****************/
class Spline : public Element2d
{
  public: 
    Spline(char * namei);
    
    void setSeqa(Seqa *s);
    
    void makeEdge();
    
    void getLineLength( Handle(Geom_Curve) curve , double *sum);
 
  private:
    Seqa *mySet;
    bool edgeAlreadyMade;
};
/*********** Class Spline End **************/

#endif