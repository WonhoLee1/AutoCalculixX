#ifndef Line_hxx
#define Line_hxx

/************** Class Line *****************/
class Line : public Element2d
{
  public: 
    Line(char * namei);
    
    void setP1(Point * p);
    
    void setP2(Point * p);
    
    Point * getP1();
    
    Point * getP2();
    
    void makeEdge();
        
  private:
    Point *p1;
    Point *p2;
};
/************ Class Line END ***************/

#endif