#ifndef Arc_hxx
#define Arc_hxx

/************ Class Line Arc ***************/
class Arc : public Element2d
{
  public: 
    Arc(char * namei);
    
    void setP1(Point* p);
    
    void setP2(Point* p);
    
    void setCnt(Point* p);
    
    Point * getP1();
    
    Point * getP2();
    
    Point * getCnt();
    
    void makeEdge();
    
  private:
    Point *p1;
    Point *p2;
    Point *cnt;
};
/********** Class Line Arc End**************/

#endif