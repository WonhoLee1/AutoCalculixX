#include <FbdReader.hxx>
#include <Point.hxx>

/************* Class Point ****************/
  Point :: Point(const char * namei)
  {
    strcpy(name,namei);   
  }
    
  char * Point :: getName()
  {
    return &name[0];
  }
  
  void Point :: setX(double xi){ x = xi;}
  void Point :: setY(double yi){ y = yi;}
  void Point :: setZ(double zi){ z = zi;}
  
  double * Point :: getX(){ return &x; }
  double * Point :: getY(){ return &y; }
  double * Point :: getZ(){ return &z; }

/************ Class Point End *************/