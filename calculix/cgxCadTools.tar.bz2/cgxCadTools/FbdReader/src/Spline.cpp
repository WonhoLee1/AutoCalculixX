#include <FbdReader.hxx>
#include <Spline.hxx>
#include <NurbsUtil.hxx>

#define PLOT 0

//two consequtive knows with a parameter less than "MultiplicityTolerance"
//appart are regared as one knot with a multiplicity 
#define MultiplicityTolerance 0.000000000001

/************* Class Spline ****************/

  Spline :: Spline(char * namei)
  {
    strcpy(name,namei);
    edgeAlreadyMade = false;
  } 
  
  void Spline :: setSeqa(Seqa *s){
    mySet = s; 
  }
  
  //============================================//
  /***		makeEdge		       **/
  /***  fit a BSpline curve to a set of points **/
  //============================================//
  void Spline :: makeEdge()
  {  
    if(edgeAlreadyMade) return;
     cout<<"Make Edge: Spline "<<name<<endl;
    if(usePia)
    {
      //==========================================//
      //iterative fitting method		  //
      //progressive-iterative approximation (PIA) //
      //less prone to oscillation 		  //
      //lower than GeomAPI_PointsToBSpline	  //
      //==========================================//
      int index = 0;
      int nPnt = (*(mySet->getSize()));
      double pCloud[nPnt][3];
      vector<Point*> pointVec = *(mySet->getPointVec());
      for(vector<Point*>::iterator p = pointVec.begin();p != pointVec.end();++p)
      {   
	pCloud[index][0]= *((*p)->getX());
	pCloud[index][1]= *((*p)->getY());
	pCloud[index][2]= *((*p)->getZ());
	index++;
      }
      if(index<3){ 
	cout<<"Seqentiel Set "<<mySet->getName()<<" contains only two few points"<<endl; 
	return;
      } 
      NurbsCurve fitCurve;
      piaFitting(pCloud,nPnt,&fitCurve,3,splineTolerance);
      TColgp_Array1OfPnt poles(1,fitCurve.nPol); 
      TColStd_Array1OfReal weights(1,fitCurve.nPol); 

      for(int i=0;i<fitCurve.nPol;i++)
      {
	gp_Pnt pnt(fitCurve.cX[i],fitCurve.cY[i],fitCurve.cZ[i]);
	poles.SetValue(i+1,pnt);      
	weights.SetValue(i+1,fitCurve.w[i]);      
      }
      vector<double> ktmp;
      vector<int> mtmp;
      double prev=-1;
      int nKnt =0;
      for(int i=0;i<fitCurve.nKnt;i++)
      {
	if(sqrt((prev-fitCurve.k[i])*(prev-fitCurve.k[i]))<MultiplicityTolerance)
	{
	  (*(mtmp.end()-1))++;
	}
	else
	{
	  ktmp.push_back(fitCurve.k[i]);
	  mtmp.push_back(1);
	  prev = fitCurve.k[i];
	  nKnt++;
	}
      }
      TColStd_Array1OfReal knots(1,nKnt);   
      TColStd_Array1OfInteger mults(1,nKnt);  
      int c=1;
      for(vector<double>::iterator e = ktmp.begin();e != ktmp.end();++e)
      {
	knots.SetValue(c,*e);
	mults.SetValue(c,mtmp[c-1]);
	c++;
      }  

    #if PLOT == 1
      cout<<"Deg: "<<fitCurve.deg<<endl; 
      for(int i=1;i<=fitCurve.nPol;i++){
	cout<<"Poles: "<< (poles.Value(i)).X()<<" "<<(poles.Value(i)).Y()<<" "<< (poles.Value(i)).Z()<<" Weights: "<<weights.Value(i)<<endl ;
      }
      
      for(c=1;c<=nKnt;c++){
	cout<<"Knots "<<knots.Value(c)<<" Mults: "<<mults.Value(c)<<endl;
      }
    #endif 
      curve = new Geom_BSplineCurve(poles,weights,knots,mults,fitCurve.deg);
      myEdge = BRepBuilderAPI_MakeEdge(curve);
      myWire = BRepBuilderAPI_MakeWire(myEdge);
      WireFrameBuilder.Add(TestWire,myEdge);
  }
  else
  {
      //==========================================//
      //BSpline fitting with Open CASCAE funktion //
      // using	GeomAPI_PointsToBSpline	          //
      // use Seqa points or intpol3 points	  //
      //==========================================//
      int n=0,curn = *(mySet->getSize());
      int mode=1;
      double lmax=0;
      double  *dl=NULL, *l=NULL, *x=NULL, *y=NULL, *z=NULL;
      double  p1[3], p2[3], p1p2[3],lp1p2;
      TColgp_Array1OfPnt pCloud(0,*(mySet->getSize())-1);
      // realloc the arrays for interpol 
      if( (l = (double *)realloc( (double *)l, curn*sizeof(double))) == NULL )
      { printf(" ERROR: realloc failure in splineNodes() l\n\n");  }
      if( (dl = (double *)realloc( (double *)dl, curn*sizeof(double))) == NULL )
      { printf(" ERROR: realloc failure in splineNodes() dl\n\n");  }
      if( (x = (double *)realloc( (double *)x, curn*sizeof(double))) == NULL )
      { printf(" ERROR: realloc failure in splineNodes() x\n\n"); }
      if( (y = (double *)realloc( (double *)y, curn*sizeof(double))) == NULL )
      { printf(" ERROR: realloc failure in splineNodes() y\n\n");  }
      if( (z = (double *)realloc( (double *)z, curn*sizeof(double))) == NULL )
      { printf(" ERROR: realloc failure in splineNodes() z\n\n");  }
      //cout<<"!.........................!"<<endl;
      vector<Point*> pointVec = *(mySet->getPointVec());
      l[0]=0;
      x[0]=p1[0]= *(pointVec[0]->getX());
      y[0]=p1[1]= *(pointVec[0]->getY());
      z[0]=p1[2]= *(pointVec[0]->getZ());
      cout<<"foundOne"<<endl;
      for(vector<Point*>::iterator p = pointVec.begin();p != pointVec.end();++p)
      {     
	if(n != 0){
	  p2[0]= *((*p)->getX());
	  p2[1]= *((*p)->getY());
	  p2[2]= *((*p)->getZ());
	  vl_result(p1,p2,p1p2);
	  x[n] = p1[0] = p2[0];
	  y[n] = p1[1] = p2[1];
	  z[n] = p1[2] = p2[2];
	  lp1p2=vl_betrag( p1p2 );
	  lmax+=lp1p2;
	  l[n] = lmax;
	}
	//cout<<"X: "<<*((*p)->getX())<<" Y: "<<*((*p)->getY())<<" Z: "<<*((*p)->getZ())<<endl;
	if(useSeqaPoints) { 
	  gp_Pnt pnt(*((*p)->getX()),*((*p)->getY()),*((*p)->getZ()));
	  pCloud.SetValue(n,pnt); 
	}
	n++;
      }    
      //cout<<"!----------------------!"<<endl;
      int iopt = 1;
      curn= n-1;
      TColgp_Array1OfPnt pCloudIntpol3(0,curn);
      double pn[3],ddl=lmax/(curn), xl = ddl;
      if(!useSeqaPoints)
      {  
	//cout<<"X: "<<x[0]<<" Y: "<<y[0]<<" Z: "<<z[0]<<endl;
	gp_Pnt pStart(x[0],y[0],z[0]);
	pCloudIntpol3.SetValue(0,pStart); 
	int i;
	for(i=0;i<(curn-1);i++)
	{
	  if(i>=1) iopt = 1;
	  pn[0] = intpol3( l, x, n, xl, &mode, 0., iopt );
	  pn[1] = intpol3( l, y, n, xl, &mode, 0., iopt );
	  pn[2] = intpol3( l, z, n, xl, &mode, 0., iopt );
	  xl+=ddl;
	  //cout<<"X: "<<pn[0]<<" Y: "<<pn[1]<<" Z: "<<pn[2]<<endl;
	  gp_Pnt pnt(pn[0],pn[1],pn[2]);
	  pCloudIntpol3.SetValue(i+1,pnt);
	} 
	gp_Pnt pEnd(x[n-1],y[n-1],z[n-1]);
	pCloudIntpol3.SetValue(i+1,pEnd); 
	//cout<<"X: "<<x[n-1]<<" Y: "<<y[n-1]<<" Z: "<<z[n-1]<<endl;
      }      
      Handle(Geom_BSplineCurve) test;
      if(!useSeqaPoints){
	curve = GeomAPI_PointsToBSpline(pCloudIntpol3,3,8,GeomAbs_C1,splineTolerance).Curve();
      test = GeomAPI_PointsToBSpline(pCloudIntpol3,3,8,GeomAbs_C1,splineTolerance).Curve();
      }
      else
      {
	curve = GeomAPI_PointsToBSpline(pCloud,3,8,GeomAbs_C1,splineTolerance).Curve();
	test = GeomAPI_PointsToBSpline(pCloud,3,8,GeomAbs_C1,splineTolerance).Curve();
      }
      for(int i = 1; i<= test->NbPoles();i++)
      {
	gp_Pnt tmp = test->Pole(i); ;
	cout<<"Pole "<<i<<" "<<tmp.X()<<" "<<tmp.Y()<<" "<<tmp.Z()<<endl;
      }
      
      for(int i = 1; i<= test->NbKnots();i++)
      {
	cout<<"knot "<<i<<" "<<test->Knot(i)<<endl;
      }
    #if PLOT == 1
       double length;
      getLineLength(curve,&length);
      if(lmax/length<0.99) {
	cout<<"Possibly a Spline osccilation --> check splineTolerance"<<endl;
	cout<<"lmax: "<<lmax<<" vs acutal length "<<length<<endl;
      }
    #endif
	myEdge = BRepBuilderAPI_MakeEdge(curve);
	myWire = BRepBuilderAPI_MakeWire(myEdge);
	WireFrameBuilder.Add(TestWire,myEdge);
    } 
    edgeAlreadyMade = true;
  }
  
void Spline :: getLineLength( Handle(Geom_Curve) curve , double *sum)
{
  double length; 
  Standard_Real uStart, uEnd;
  *sum = 0;
  if(! curve.IsNull())
  {  
    uStart = curve->FirstParameter();
    uEnd = curve->LastParameter();
    GeomAdaptor_Curve acurve(curve,uStart,uEnd);
    length = GCPnts_AbscissaPoint::Length(acurve,uStart,uEnd);
    

    *sum+=length;
  }
  else
    cout<<"NULL"<<endl;
}

/*********** Class Spline End **************/
