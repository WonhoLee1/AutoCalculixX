#include <FbdReader.hxx>
#include <Surface.hxx>

/************ Class BSurface ***************/

  Surface :: Surface(char * namei)
  {
    strcpy(name,namei);
  }
  
  void Surface :: setSurf(Handle(Geom_Surface) aSurf){
    mySurf = aSurf;
  }
  
  Handle(Geom_Surface) Surface :: getSurf(){
    return mySurf;
  }
  
  char * Surface :: getName(){
    return &name[0];
  } 

/********** Class BSurface End *************/