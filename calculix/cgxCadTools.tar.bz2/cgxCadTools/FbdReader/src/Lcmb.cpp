#include <FbdReader.hxx>
#include <Lcmb.hxx>
#include <NurbsUtil.hxx>

#define PLOT 0

/************** Class Lcmb *****************/

  Lcmb :: Lcmb(char * namei)
  {
    strcpy(name,namei);
  } 

  //====================================================//
  // Using the compCurve function, a single B-Spline is //
  // bgenerated to represent a line combine (LCMB)	//
  //====================================================//
  void Lcmb :: makeEdge()
  {
    int currentLine=1;
    Standard_Real c_start;
    Standard_Real c_end;
    cout<<"Link Edges: Lcmb "<<name<<endl;
    vector<Handle(Geom_Curve)> curveList;
    vector<int*> curveDivisions;
    for(vector<Element2d*>::iterator e = myLines.begin();e != myLines.end();++e)
    {  
      (*e)->makeEdge();
      Handle(Geom_Curve) curveOri = BRep_Tool::Curve(*((*e)->getEdge()), c_start, c_end);
      //cout<<"c_start "<<c_start<<" c_end "<<c_end<<endl;
      if(orientation[currentLine-1] == false){
	curve= curveOri->Reversed();//save a reversed copy
	cout<<"Reversed"<<endl;
      }
      else curve = curveOri;//save a copy
	    
      curveList.push_back(curve);
      curveDivisions.push_back((*e)->getDiv());
      //cout<<*(*e)->getDiv()<<endl;
      currentLine++;
    }   
    curve = compCurve(&curveList, &curveDivisions);
    myEdge = BRepBuilderAPI_MakeEdge(curve);
    myWire = BRepBuilderAPI_MakeWire(myEdge);
    cout<<"done"<<endl;
  }
    
  void Lcmb :: addElement2d(Element2d * el, bool forward){
    myLines.push_back(el);
    if(forward) orientation.push_back(true);
    else orientation.push_back(false);
  }

/************ Class Lcmb End ***************/
