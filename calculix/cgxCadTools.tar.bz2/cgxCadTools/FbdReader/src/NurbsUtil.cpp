#include <FbdReader.hxx>
#include <NurbsUtil.hxx>
#include <math.h>

//two consequtive knows with a parameter less than "MultiplicityTolerance"
//appart are regared as one knot with a multiplicity 
#define MultiplicityTolerance 0.000000000001
//tolerance for chaining consequtive edges
#define chainCurveTolerance 0.00000001

#define PLOT 0

void rotateBSpline(double *p1, double *p2, NurbsCurve * myCurve ,BSplineSurface * mySurf)
{
  double xAxis[3], yAxis[3] ,zAxis[3];//local coordinate system
  double origin[3];
  double p1cPoint[3], cPointTmp[3];
  double tmpVec[3],p1p2[3];
  double scalProd, length;
  double radius;
  
  int i,j,l,m;
  
 //Matrix M: 	(x1,  y1,  z1)
 //		(x2,  y2,  z2)
 //		(x3,  y3,  z3)
 // [column,row] bzw. [zeile,spalte]
  double M [3][3];//matrix for new coordinate system
  double t[3];//translation for new coordinate system
  
  //Define BSpline-circle
  double circlePoint[9][3]= {{1,0,0},{1,1,0},{0,1,0},
			    {-1,1,0},{-1,0,0},{-1,-1,0},
			    {0,-1,0},{1,-1,0},{1,0,0}};
  double circlePointScaled[9][3];
				  
  double wCircle[9]={1,0.707107,1,0.707107,1,0.707107,1,0.707107,1};
				  
  double kCircle[12]={0,0,0,0.25,0.25,0.5,0.5,0.75,0.75,1,1,1};		  
 
  double *resVKnot = NULL;
  double *resUKnot = NULL;
  double *resWeight = NULL;
  double *rescX=NULL, *rescY = NULL, *rescZ = NULL;
  
  if((resVKnot = (double *)realloc((double *)resVKnot, 12*sizeof(double))) == NULL )
  { printf(" ERROR: realloc failure resVKnot\n\n"); }
  
  if((resUKnot = (double *)realloc((double *)resUKnot, (myCurve->nKnt)*sizeof(double))) == NULL )
  { printf(" ERROR: realloc failure resUKnot\n\n"); }
  
  if((resWeight = (double *)realloc((double *)resWeight, (myCurve->nPol)*9*sizeof(double))) == NULL )
  { printf(" ERROR: realloc failure resWeights\n\n"); }
  
  if((rescX = (double *)realloc((double *)rescX, (myCurve->nPol)*9*sizeof(double))) == NULL )
  { printf(" ERROR: realloc failure rescX\n\n"); }
  
  if((rescY = (double *)realloc((double *)rescY, (myCurve->nPol)*9*sizeof(double))) == NULL )
  { printf(" ERROR: realloc failure rescY\n\n"); }
  
  if((rescZ = (double *)realloc((double *)rescZ, (myCurve->nPol)*9*sizeof(double))) == NULL )
  { printf(" ERROR: realloc failure rescZ\n\n"); }

  double resPol[(myCurve->nPol)*9][3];
  
  //calculate coordinate axis
  
  vl_result(p1,p2,zAxis);//z-Axis of local coordinate system
  cPointTmp[0]=myCurve->cX[0];//Fist control point
  cPointTmp[1]=myCurve->cY[0];
  cPointTmp[2]=myCurve->cZ[0];
  vl_result(p1,cPointTmp,p1cPoint);
  vl_sprod(p1cPoint,zAxis,&scalProd);
  length=vl_betrag(zAxis);
  length = scalProd/(length*length);
  vl_scal(&length,zAxis,tmpVec);
  vl_add(p1,tmpVec,origin);//origin of local coordinate system
  vl_result(origin,p2,zAxis);//z-Axis of local coordinate system
  vl_norm(zAxis,zAxis);//scale to length 1
  vl_result(origin,cPointTmp,xAxis);//x-Axis of local coordinate system
  vl_norm(xAxis,xAxis);//scale to length 1
  vl_prod(zAxis,xAxis,yAxis);//y-Axis of local coordinate system
  //calculate rotaion matrix
  for(i=0;i<3;i++){
    M[i][0]=xAxis[i];//wirte x-Axis to fisrt column
    M[i][1]=yAxis[i];//wirte y-Axis to second column
    M[i][2]=zAxis[i];//wirte z-Axis to third column
  }
  
  
  for(i=0;i<(myCurve->nPol);i++)
  {
      vl_result(p1,p2,p1p2);
      cPointTmp[0]=myCurve->cX[i];//control point Ci
      cPointTmp[1]=myCurve->cY[i];
      cPointTmp[2]=myCurve->cZ[i];
      vl_result(p1,cPointTmp,p1cPoint);
      vl_sprod(p1cPoint,p1p2,&scalProd);
      length=vl_betrag(p1p2);
      length = scalProd/(length*length);
      vl_scal(&length,p1p2,tmpVec);
      vl_add(p1,tmpVec,t);
      vl_result(t,cPointTmp,tmpVec);
      radius = vl_betrag(tmpVec);
      
      //"scale circle points
      for(l=0;l<9;l++){
	for(m=0;m<3;m++){
	  circlePointScaled[l][m] = radius * circlePoint[l][m];
	}
      }
      
      //calcutale control points
      for(j=0;j<9;j++){//calculate control points of circle
	vl_trans(M,t,circlePointScaled[j], resPol[i*9+j]);//calculate controll points of the rotated surface
	rescX[i*9+j]=resPol[i*9+j][0];
	rescY[i*9+j]=resPol[i*9+j][1];
	rescZ[i*9+j]=resPol[i*9+j][2];
	resWeight[i*9+j] = wCircle[j]*(myCurve->w[i]);//calculate weights
      }
    }
    //calculate u-Knots 
    for(j=0;j<(myCurve->nKnt);j++){    
      resUKnot[j] = myCurve->k[j];
    }
    //calculate v-Knots 
    for(j=0;j<12;j++){    
      resVKnot[j] = kCircle[j];
    }
    //write result to struct
    mySurf->uDeg = myCurve->deg;
    mySurf->vDeg = 2;
    mySurf->nUPol = myCurve->nPol;
    mySurf->nVPol = 9;  
    mySurf->nUKnt = myCurve->nKnt;
    mySurf->nVKnt = 12;  
    mySurf->uKnt = resUKnot;
    mySurf->vKnt = resVKnot;  
    
    mySurf->weights = resWeight;
    mySurf->cX =rescX;
    mySurf->cY =rescY;
    mySurf->cZ =rescZ;    
}

inline double wik(int k,int i,double *u,double x)
{
  if((u[i+k-1]-u[i])!=0){
    return (x-u[i])/(u[i+k-1]-u[i]);
  }
  else
    return 0;
}

inline double deBoor(int k, int i, double * u ,double x)
{     
  if(x>1)x=1;
  if(k==1){
    if(x >= u[i] && x <= u[i+1]) return 1;
    else return 0;
  }
  else {
    return wik(k,i,u,x)*deBoor(k-1,i,u,x)+(1-wik(k,i+1,u,x))*deBoor(k-1,i+1,u,x);
  }
}

inline void calculateBSpline(double * pnt, NurbsCurve * myCurve,double u, bool rational)
{
  double sumX=0,sumY=0,sumZ=0,N,tmp=0;
  int i,j;
  for(j=0;j<(myCurve->nPol);j++){
    tmp+=(myCurve->w[j])*deBoor(myCurve->deg+1,j,(myCurve->k),u);
  }
  if(tmp!=0){
    for(i=0;i<(myCurve->nPol);i++)
    {
      N=(myCurve->w[i])*deBoor(myCurve->deg+1,i,(myCurve->k),u)/tmp;   
      sumX+= myCurve->cX[i]*(N);
      sumY+= myCurve->cY[i]*(N);
      sumZ+= myCurve->cZ[i]*(N);
    }
  }
  else{
    sumX = sumY = sumZ = 0;
  }
  pnt[0]=sumX;
  pnt[1]=sumY;
  pnt[2]=sumZ;
}

/**************************************************/
/*** 	fitting algorithm for B-Splines		***/
/*** progressive-iterative approximation (PIA)	***/
/**************************************************/
void piaFitting(double pCloud [][3],int nPnt,NurbsCurve * fitCurve, int deg, double tolerance)
{
  fitCurve->k = NULL;fitCurve->cX = NULL;fitCurve->cY = NULL;fitCurve->cZ = NULL;fitCurve->w = NULL;
  int nCPnt = nPnt + 2, i;  
  if((fitCurve->k = (double *)realloc((double *)fitCurve->k,(nPnt+2*deg)*sizeof(double))) == NULL )
  { printf(" ERROR: realloc failure\n\n"); }  
  if((fitCurve->cX = (double *)realloc((double *)fitCurve->cX,nCPnt*sizeof(double))) == NULL )
  { printf(" ERROR: realloc failure\n\n"); }    
  if((fitCurve->cY = (double *)realloc((double *)fitCurve->cY,nCPnt*sizeof(double))) == NULL )
  { printf(" ERROR: realloc failure\n\n"); }    
  if((fitCurve->cZ = (double *)realloc((double *)fitCurve->cZ,nCPnt*sizeof(double))) == NULL )
  { printf(" ERROR: realloc failure\n\n"); }    
    if((fitCurve->w = (double *)realloc((double *)fitCurve->w,nCPnt*sizeof(double))) == NULL )
  { printf(" ERROR: realloc failure\n\n"); }   
  
  
  fitCurve->deg = deg;//cubic Bspline
  fitCurve->nPol = nCPnt;
  fitCurve->nKnt = nPnt+2*deg;
  fitCurve->deg = deg;
  //Define curve as clamped: 
  //Start knodes have multiplicity  deg + 1
    //End knodes have multiplicity  deg + 1
  for(i=0;i<=deg;i++)
  {
    fitCurve->k[i]=0;
    fitCurve->k[fitCurve->nKnt-(i+1)]=1;
  }
  
  double dist=0, p1p2[3], p1[3],p2[3];
  double du,dControll[3];
  
  //sum up distances between points
  for(i=1;i<nPnt;i++){
    vl_result(pCloud[i],pCloud[i-1],p1p2);
    dist+=vl_betrag(p1p2);
  }
  
   //set pCloud points as control points 
   fitCurve->cX[0]=pCloud[0][0];
   fitCurve->cY[0]=pCloud[0][1];
   fitCurve->cZ[0]=pCloud[0][2];
   fitCurve->w[0]=1;
   fitCurve->cX[nCPnt-1]=pCloud[nPnt-1][0];
   fitCurve->cY[nCPnt-1]=pCloud[nPnt-1][1];
   fitCurve->cZ[nCPnt-1]=pCloud[nPnt-1][2];
   fitCurve->w[nCPnt-1]=1;
  
  for(i=1;i<=nPnt;i++){
    fitCurve->cX[i]=pCloud[i-1][0];
    fitCurve->cY[i]=pCloud[i-1][1];
    fitCurve->cZ[i]=pCloud[i-1][2];
    fitCurve->w[i]=1;
  }
  
  //calculate initial knot vector via chord-length parametrization
  for(i=1;i<nPnt;i++){
    p1[0]=pCloud[i-1][0];
    p1[1]=pCloud[i-1][1];
    p1[2]=pCloud[i-1][2];
    p2[0]=pCloud[i][0];
    p2[1]=pCloud[i][1];
    p2[2]=pCloud[i][2];
    vl_result(p1,p2,p1p2);
    du=(vl_betrag(p1p2))/dist;
    fitCurve->k[i+deg]=fitCurve->k[i+deg-1]+du;
  }
  
  double error=10, errorOld=0;
  int c, iter = 1;
  //interation loop for PIA fitting
  do{
    //iterate over all inner knots
    c=0;
    errorOld = error;
    error=0;
    for(i=(deg);i<((fitCurve->nKnt)-(deg));i++)
    {     
      calculateBSpline(dControll,fitCurve,fitCurve->k[i],true);//calculate point for parameter with current control points
      p1[0]=pCloud[c][0];
      p1[1]=pCloud[c][1];
      p1[2]=pCloud[c][2];
      vl_result(dControll,p1,p2);//get the difference between calculated spline point and control point
      if(vl_betrag(p2)>error) 
	error=vl_betrag(p2);//get the difference to current control point
      p1[0]=fitCurve->cX[c+1];
      p1[1]=fitCurve->cY[c+1];
      p1[2]=fitCurve->cZ[c+1];
      vl_add(p1,p2,dControll); 
      fitCurve->cX[c+1]=dControll[0];
      fitCurve->cY[c+1]=dControll[1];
      fitCurve->cZ[c+1]=dControll[2];
      c++;
    }
    #if PLOT == 1
    cout<<"Error: "<<error<<" after "<<iter<<"-iterations"<<endl;
    #endif
    iter++;
  }while(sqrt((error)*(error))>tolerance && iter <150);
  cout<<"BSpline fitting ... done"<<endl;
  cout<<"Error: "<<error<<" after "<<iter<<"-iterations"<<endl;
}

  //======================================================//
  // this function combines the curves of multiple	  //	
  // element2d-objekts to one B-Spline curve		  //	
  //======================================================//
  Handle_Geom_BSplineCurve compCurve(vector<Handle(Geom_Curve)> *curveList, vector<int*> * curveDivisions)
  {
    int currentLine;
    Standard_Real c_start=0;
    Standard_Real c_end=1;
    Standard_Integer MinM = 1;
    Geom_BoundedCurve * tCurve;
    GeomConvert_CompCurveToBSplineCurve * compCurve = new GeomConvert_CompCurveToBSplineCurve  (Convert_TgtThetaOver2 ); 
    currentLine = 1;
    Handle_Geom_Curve curve;
    gp_Pnt start,end;
    int counter=0,nCurves;
    double length, combinedLength=0;
    vector<double> curveLength; 
    for(vector<Handle(Geom_Curve)>::iterator e = curveList->begin();e != curveList->end();++e)
    {    
      start = (*e)->Value(c_start);      
      GeomAdaptor_Curve acurve(*e,c_start,c_end);
      length = GCPnts_AbscissaPoint::Length(acurve,c_start,c_end);
      curveLength.push_back(length);
      combinedLength += length;
      
      if(counter!=0 && start.Distance(end) != 0) cout<<"ERROR: edges not chained"<<endl;     
      end = (*e)->Value(c_end);
      tCurve = new Geom_TrimmedCurve(*e, c_start, c_end);  
      compCurve->Add(tCurve,chainCurveTolerance, Standard_False, Standard_True, MinM) ; 
      end = (*e)->Value(c_end);
      counter++;
    }
    
    nCurves = counter;//save number of curves
    
    double u,du;
    int resolution = 0, index = 0, nPnt = 0;
    int curveResolution[nCurves];
    
    
    for(int i=0;i<nCurves;i++){
      resolution += (*((*curveDivisions)[i]));
    }
    
    //resolution *= 2;
    
    for(int i=0;i<nCurves;i++)
    {
      if((*curveDivisions).size()<(nCurves-1)) cout<<"no Divisions"<<endl;
      curveResolution[i] = curveLength[i]/combinedLength * resolution; //c(*((*curveDivisions)[i])); //
      if(curveResolution[i]<3) { cout<<"Division 1 increased to 2"<<endl; curveResolution[i] = 3;}
      nPnt += curveResolution[i];     
    }
    
    nPnt = nPnt - (nCurves-1);
    double pCloud[nPnt][3];
    gp_Pnt pTmp; 
    
    counter = 0;
    index = 0;
    for(vector<Handle(Geom_Curve)>::iterator c = curveList->begin();c != curveList->end();++c)
    { 
      du=1;
      du=du/curveResolution[counter];
      u=0;
      //retrieve points on preliminary B-Spline with constant parameter spacing
      for(int i=0;i<curveResolution[counter]-1;i++)
      {   
	(*c)->D0(u,pTmp);
	pCloud[index][0]= pTmp.X();
	pCloud[index][1]= pTmp.Y();
	pCloud[index][2]= pTmp.Z();
	u+=du;
	index++;
      }
      if(counter >= nCurves -1){
	//set last point as control point explicitly to avoid rouding error
	(*c)->D0(1,pTmp);
	pCloud[index][0]= pTmp.X();
	pCloud[index][1]= pTmp.Y();
	pCloud[index][2]= pTmp.Z();      
	index++;
      }
      counter++;
    }

    Handle(Geom_BSplineCurve) combiCurve; //= compCurve->BSplineCurve();//preliminary curve
    
    //========================================================//
    //Perform the PIA-Splitting algorithm with points from    //	
    //the preliminary B-Spline				      //
    //The resulting cubic B-Spline is C2 continious 	      //
    //========================================================//
    NurbsCurve fitCurve;
    piaFitting(pCloud,nPnt,&fitCurve,3,splineTolerance);
    TColgp_Array1OfPnt poles(1,fitCurve.nPol); 
    TColStd_Array1OfReal weights(1,fitCurve.nPol); 

    for(int i=0;i<fitCurve.nPol;i++)
    {
      gp_Pnt pnt(fitCurve.cX[i],fitCurve.cY[i],fitCurve.cZ[i]);
      poles.SetValue(i+1,pnt);      
      weights.SetValue(i+1,fitCurve.w[i]);      
    }
    vector<double> ktmp;
    vector<int> mtmp;
    double prev=-1;
    int nKnt =0;
    for(int i=0;i<fitCurve.nKnt;i++)
    {
      if(sqrt((prev-fitCurve.k[i])*(prev-fitCurve.k[i]))<MultiplicityTolerance)
      {
	(*(mtmp.end()-1))++;
      }
      else
      {
	ktmp.push_back(fitCurve.k[i]);
	mtmp.push_back(1);
	prev = fitCurve.k[i];
	nKnt++;
      }
    }
    TColStd_Array1OfReal knots(1,nKnt);   
    TColStd_Array1OfInteger mults(1,nKnt);  
    int c=1;
    for(vector<double>::iterator e = ktmp.begin();e != ktmp.end();++e)
    {
      knots.SetValue(c,*e);
      mults.SetValue(c,mtmp[c-1]);
      c++;
    }  
    
  #if PLOT == 1
    cout<<"Deg: "<<fitCurve.deg<<endl; 
    for(int i=1;i<=fitCurve.nPol;i++){
      cout<<"Poles: "<< (poles.Value(i)).X()<<" "<<(poles.Value(i)).Y()<<" "<< (poles.Value(i)).Z()<<" Weights: "<<weights.Value(i)<<endl ;
    }
    
    for(c=1;c<=nKnt;c++){
      cout<<"Knots "<<knots.Value(c)<<" Mults: "<<mults.Value(c)<<endl;
    }
  #endif   
     combiCurve =  new Geom_BSplineCurve(poles,weights,knots,mults,fitCurve.deg);
    return combiCurve;
  } 

