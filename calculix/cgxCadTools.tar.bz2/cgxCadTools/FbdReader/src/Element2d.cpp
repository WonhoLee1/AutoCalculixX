#include <FbdReader.hxx>
#include <Element2d.hxx>

/*********** Class Element2d ***************/
/*************** Abstract ******************/
  
  char * Element2d :: getName(){
    return &name[0];
  }

  Handle_Geom_Curve Element2d :: getCurve() {
    return curve;
  }
  
  void Element2d :: setCurve(Handle_Geom_Curve c){
    curve = c; 
  }
  
  TopoDS_Wire * Element2d :: getWire(){
    return &myWire;
  }
  
  TopoDS_Edge * Element2d :: getEdge(){
    return &myEdge;
  }
  
  void Element2d :: setDiv(int d){
    div = d;
  }
  
  int * Element2d :: getDiv(){
    return &div;
  }

/*********** Class Element2d End ***********/