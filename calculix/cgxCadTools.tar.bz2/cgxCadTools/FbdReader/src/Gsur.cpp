#include <FbdReader.hxx>
#include <Gsur.hxx>
#include <NurbsUtil.hxx>

#define PLOT 0

/************** Class Gsur *****************/

  Gsur :: Gsur(char * namei)
  {
    strcpy(name,namei);
    blend = false;
    freeFace = true;
  }  
  
  void Gsur :: addWire(TopoDS_Wire * w, bool forward, int *div){
    TopoDS_Wire wire = *w;
    //Correct Orientation for this Face 
    //-> Edges/Wires might be shared between Faces and thus have a different Orientation
    if(!forward) wire.Orientation(TopAbs_REVERSED);
    divisions.push_back(div);
    myWire.push_back(wire);
    wireUsed.push_back(false);
  } 
  
  //******************************************************//
  //Prepare Constraints for Face filling to imitate Blend //
  //Merg Edges to get no more than a total of 4 Edges     //
  //Constraint filling algorithm works up to 4 Edges	  //
  //******************************************************//
  void Gsur :: prepareConstraints()
  {
    TopExp_Explorer e;
    Standard_Real c_start, c_end;
    nConstraint = 0;
    Handle(Geom_BSplineCurve) nCurve;
    bool lastEdge;
    for(vector<TopoDS_Wire>::iterator wcon = boundary.begin();wcon != boundary.end();++wcon)
    {     
      double prevP[3],endP[3], startP[3],postP[3],refStart[3],refEnd[3]={0,0,0}, sclProd, refSclProd = 0.95;
      gp_Pnt pre,end,start,post;
      vector<Handle(Geom_Curve)> curveContainer;;
      e.Init(*wcon,TopAbs_EDGE);
      lastEdge =false;
      int nEdge = 0;
      vector<int*> curveDivisions;
      while(e.More())
      {   	
	Handle(Geom_Curve) curveOri = BRep_Tool::Curve(TopoDS::Edge(e.Current()), c_start, c_end);
	Handle(Geom_Curve) curve;
	//correct curve orientation if necesarry
	if((TopoDS::Edge(e.Current())).Orientation()==TopAbs_REVERSED){
	  curve= curveOri->Reversed();//save a reversed copy
	#if PLOT == 1
	 cout<<"Reversed"<<endl;
	#endif
	}
	else curve= curveOri;//save a copy
	  
      #if PLOT == 1 //Display start  and end point to manually varify correct curve orientation
	gp_Pnt p1 = curve->Value(c_start);
	gp_Pnt p2 = curve->Value(c_end);
	cout<<"P1: "<<p1.X()<<" , "<<p1.Y()<<" , "<<p1.Z()<<endl;
	cout<<"P2: "<<p2.X()<<" , "<<p2.Y()<<" , "<<p2.Z()<<endl;
      #endif
	  
	//=========================================================//
	// calculate a vector tangential to the end of the curve   //
	//=========================================================//
	pre = curve->Value(c_end-((c_end-c_start)/100));//spline point before end
	end = curve->Value(c_end); //spline end points
	prevP[0]=pre.X();
	prevP[1]=pre.Y();
	prevP[2]=pre.Z();
	endP[0]=end.X();
	endP[1]=end.Y();
	endP[2]=end.Z();
	
	//=========================================================//
	// calculate a vector tangential to the start of the curve //
	//=========================================================//
	start = curve->Value(c_start);//spline start point
	post = curve->Value(c_start+((c_end-c_start)/100)); //spline point next to start point
	startP[0]=start.X();
	startP[1]=start.Y();
	startP[2]=start.Z();
	postP[0]=post.X();
	postP[1]=post.Y();
	postP[2]=post.Z();
	
	vl_result(startP,postP,refEnd);//update tangential vector
	vl_norm(refEnd,refEnd);//normalise tangential vector

	vl_sprod(refEnd,refStart,&sclProd);//calculate cosinus of angle between subsequent lines
      #if PLOT == 1 
	cout<<"Scalar Product: "<<sclProd<<endl;
      #endif
      
	vl_result(prevP,endP,refStart);//update tangential vector
	vl_norm(refStart,refStart);//normalise tangential vector
	
	//search for subsequent edges, that are suited as combined lines
	if(sclProd > refSclProd)
	{
	    //subsequent edges are nearly tangent 
	    if(lastEdge == true)
	    {
	      //first and last edges are tangent 
	      cout<<"--> combine Lines"<<endl;
	      curveContainer.push_back(constraints[0]);
	      curveDivisions.push_back(divisions[nEdge]);
	      cout<<*divisions[nEdge]<<endl;
	      nCurve = compCurve(&curveContainer,&curveDivisions);
	      constraints[0] = nCurve;	    
	      constraints.pop_back();
	      nConstraint--;
	      break;
	    }
	    else
	    {
	      cout<<"--> combine Lines"<<endl;
	      curveContainer.push_back(curve);
	      curveDivisions.push_back(divisions[nEdge]);
	      cout<<*divisions[nEdge]<<endl;
	      nCurve = compCurve(&curveContainer,&curveDivisions);
	      constraints[nConstraint-1] = nCurve;
	    }
	}
	else
	{
	  if(lastEdge == true) {break;}
	  curveContainer.clear();
	  curveDivisions.clear();
	  curveContainer.push_back(curve);
	  curveDivisions.push_back(divisions[nEdge]);
	  nCurve = GeomConvert::CurveToBSplineCurve(curve,Convert_QuasiAngular);
	  constraints.push_back(nCurve);
	  nConstraint++;
	}
	e.Next(); 
	nEdge ++;
	//case last edge
	if(e.More()==false){
	  lastEdge = true;
	  nEdge = 0;
	  e.Init(*wcon,TopAbs_EDGE);  
	}
      }   
    } 
    
    //Blended face with more than 4 edges 
    //there are not enough edges that are nearly tangential
    //edges are chained in arbitrary order
    if(nConstraint > 4)
    {
      cout<<"edges have to be chained arbitrarily"<<endl;
      constraints.clear();
      Standard_Real tolerance = 0.00001;
      Standard_Integer MinM = 0;
      nConstraint = 0;
      Geom_BoundedCurve * tCurve;
      GeomConvert_CompCurveToBSplineCurve * compCurve = new GeomConvert_CompCurveToBSplineCurve  (Convert_TgtThetaOver2); 
      for(vector<TopoDS_Wire>::iterator wcon = boundary.begin();wcon != boundary.end();++wcon)
      {
	for (e.Init(*wcon,TopAbs_EDGE);e.More(); e.Next())
	{   	
	  Handle(Geom_Curve) curveOri = BRep_Tool::Curve(TopoDS::Edge(e.Current()), c_start, c_end);
	  Handle(Geom_Curve) curve;
	  //reverse curve orientation if necesarry
	  if((TopoDS::Edge(e.Current())).Orientation()==TopAbs_REVERSED){
	    curve= curveOri->Reversed();//save a reversed copy
	    cout<<"Done"<<endl;
	  }
	  else curve= curveOri;//save a copy
	#if PLOT == 1 //Display star  and end point to manualy varify vorrect curve orientation
	  gp_Pnt p1 = curve->Value(c_start);
	  gp_Pnt p2 = curve->Value(c_end);
	  cout<<"P1: "<<p1.X()<<" , "<<p1.Y()<<" , "<<p1.Z()<<endl;
	  cout<<"P2: "<<p2.X()<<" , "<<p2.Y()<<" , "<<p2.Z()<<endl;
	#endif
	  tCurve = new Geom_TrimmedCurve(curve, c_start, c_end);
	  if (curve->DynamicType() == STANDARD_TYPE(Geom_BSplineCurve)) 
	  {	
	    //cout<<"++"<<endl;
	    Handle(Geom_BSplineCurve) nCurve;
	    if(nConstraint >= 4)
	    {
	      compCurve->Add(tCurve,tolerance, Standard_False, Standard_True, MinM);
	      nCurve = compCurve->BSplineCurve();
	    }
	    else
	    {
	      nCurve = GeomConvert::CurveToBSplineCurve(curve,Convert_QuasiAngular);
	      if(nConstraint == 3)
	      {
		compCurve->Add(tCurve,tolerance, Standard_False, Standard_True, MinM) ;
	      }
	    }
	    if(nConstraint >=4)
	    {
	      constraints[3]=nCurve;
	    }
	    else
	    {
	      constraints.push_back(nCurve);
	      nConstraint ++;
	    } 	  
	  }
	  else
	  {
	    cout<<"Wrong curve Type in constraint"<<endl;
	  }
	}  
      }
    }
  }
  
  void Gsur :: setBlend(bool b){
    blend = true;
  }
  
  //***************************************************//
  //Link Wires/Edges to form closed loops for trimming //
  //***************************************************//
  void Gsur :: constructBoundary()
  {
    cout<<"Sort Boundary Wires!"<<endl;
    int counter1 = 0,counter2 = 0;
    bool foundOne;
    for(vector<TopoDS_Wire>::iterator wcon = myWire.begin();wcon != myWire.end();++wcon)
    { 
      if(wireUsed[counter1]==false)
      {
	cout<<"Closed Wire loop ( "<<name<<" )"<<endl;
	//Start a new loop with a wire that is not used
	BRepBuilderAPI_MakeWire * wireTester = new BRepBuilderAPI_MakeWire();
	BRepBuilderAPI_MakeWire * wireMaker = new BRepBuilderAPI_MakeWire();
	wireMaker->Add(*wcon);
	wireTester->Add(*wcon);
	wireUsed[counter1]=true;
      #if PLOT == 1	
	cout<<"+ Edge "<<counter1<<endl;
      #endif
	//Link unused wires to the initial initial wire
	do{
	  counter2 =0;
	  foundOne = false;
	  for(vector<TopoDS_Wire>::iterator w = myWire.begin();w != myWire.end();++w)
	  { 	 
	    if(w != wcon && wireUsed[counter2]==false)
	    {
	      wireTester->Add(*w);       
	      if(wireTester->IsDone())//Check for connectivity
	      {
		wireMaker->Add(*w); //Next Wire found and added to the loop		
		wireUsed[counter2]=true;
	      #if PLOT == 1	
		cout<<"+ Edge "<<counter2<<endl;
	      #endif
		foundOne = true;
		break;
	      }
	    }
	    counter2++;
	  }	  
	}while(foundOne);	
	TopoDS_Wire aWire = wireMaker->Wire();
	if(wireMaker->IsDone()==true)
	  cout<<"Status - success"<<endl;
	else
	    cout<<"Status - failed"<<endl;
		      
	boundary.push_back(aWire);//Add loop to Boundary-List  
      }
      counter1++;
    }
  }
  
  char * Gsur :: getName(){
    return &name[0];
  } 
  
  void Gsur :: setSurf(Handle(Geom_Surface) aSurf){
    mySurf = aSurf;
  }
  
  TopoDS_Face * Gsur :: getFace()
  {
    return &myFace;
  }
  
  void Gsur :: setFree(bool f)
  {
    freeFace = f;
  }
  
  bool Gsur :: getFree()
  {
    return freeFace;
  }
  
  
  //*********************************************************//
  //Generate Surface for Faces that do not have a Surface    //
  //Imitates Blend operation used in cgx                     //
  ////*******************************************************//
  void Gsur :: fillSurface()
  {
    prepareConstraints();
    cout<<"Blend Surface Interpolate --> "; 
    GeomFill_BSplineCurves * fillSurf = new GeomFill_BSplineCurves ();
    switch(nConstraint)
    {
      case 2:
	cout<<"2 ................."<<endl;
	fillSurf->Init(constraints[0],constraints[1],GeomFill_CoonsStyle );
	break;
      case 3:
	cout<<"3 ................."<<endl;
	fillSurf->Init(constraints[0],constraints[1],constraints[2],GeomFill_CoonsStyle );	
	break;
      case 4:
	cout<<"4 ................."<<endl;
	fillSurf->Init(constraints[0],constraints[1],constraints[2],constraints[3],GeomFill_CoonsStyle );	
	break;
      default:
	cout<<"Error: To many Constraints!"<<endl;
	break;
    }
    Handle(Geom_BSplineSurface)  nSurf =  fillSurf->Surface();
    setSurf(nSurf);
  }
  
  //******************************************************//
  //Assemble Face from Surface and Constrains by trimming //
  //******************************************************//
  void Gsur :: composeFace()
  {
    if(blend){
      cout<<"Interpolate Surface by constraints: "<<endl;
      fillSurface();
      cout<<"--> Done"<<endl;
    }
    TopExp_Explorer e;
    if(mySurf.IsNull()) {cout<<"Error no Surface Defined"<<endl; return; }
    BRepBuilderAPI_MakeFace * faceMaker = new BRepBuilderAPI_MakeFace(mySurf,*(boundary.begin()));
    for(vector<TopoDS_Wire>::iterator w = (boundary.begin()+1);w != boundary.end();++w)
    {
	(*w).Reversed();
	faceMaker->Add(*w);    
    }   
    myFace = faceMaker->Face();
    
    if(faceMaker->IsDone()==true) cout<<"Face "<<name<<" --> done"<<endl; 
    else cout<<"Fail"<<endl;
  }  

/************ Class Gsur End ***************/