#include <FbdReader.hxx>
#include <Gbod.hxx>

/************** Class Gbod *****************/    
  Gbod :: Gbod(char * namei)
  {
    strcpy(name,namei);
  }
  
  char * Gbod :: getName()
  {
    return &name[0];
  }
  
  void Gbod :: addFace(TopoDS_Face * f)
  {
    myBoundingBox.push_back(f);
  }
  
  TopoDS_Shell *  Gbod :: joinFaces(BRep_Builder * builder)
  {
    builder->MakeShell(shell);
    cout<<"Faces ";
    for(vector<TopoDS_Face*>::iterator f = myBoundingBox.begin();f != myBoundingBox.end();++f)
    {
	if(!(*f)->IsNull()){
	builder->Add(shell,**f);
	cout<<" + ";
	}
	else
	{
	  cout<<"-----   Missing Face!!! ---------";
	}
    }
    cout<<endl;
    return &shell;
  }         
/************ Class Gbod END ***************/
