#include <FbdReader.hxx>
#include <BSplineCurve.hxx>

/************ Class BSplineCurve ***********/


    BSplineCurve :: BSplineCurve(char * namei)
    {
        strcpy(name,namei);  
    };
        
    
    void BSplineCurve :: makeEdge()
    {    	      
        myEdge = BRepBuilderAPI_MakeEdge(curve);
        myWire = BRepBuilderAPI_MakeWire(myEdge);
        myBuilder.Add(TestWire,myEdge);
    }


/********* END Class BSplineCurve **********/
