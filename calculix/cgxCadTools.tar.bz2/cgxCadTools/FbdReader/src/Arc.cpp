#include <FbdReader.hxx>
#include <Arc.hxx>

/************ Class Line Arc ***************/
  Arc :: Arc(char * namei)
  {
    strcpy(name,namei);
  }
  
  void Arc :: setP1(Point* p){
    p1 =p;
  }
  
  void Arc :: setP2(Point* p){
    p2 = p;
  }
  
  void Arc :: setCnt(Point* p){
    cnt = p;
  }
  
  Point * Arc :: getP1(){
    return p1;
  }
  
  Point * Arc :: getP2(){
    return p2;
  }
  
  Point * Arc :: getCnt(){
    return cnt;
  }
  
  void Arc :: makeEdge()
  {
    cout<<"Make Edge: Arc "<<name<<endl;
    double v1[3],v2[3],v12[3],v12i[3],vtmp[3],vres[3];
    double a,ai,vscal,vscali,dlv12,lengthi;
    double pp1[3],pp2[3],pcnt[3],piv[3];
    pp1[0] = *(p1->getX());
    pp1[1] = *(p1->getY());
    pp1[2] = *(p1->getZ());
    
    pp2[0] = *(p2->getX());
    pp2[1] = *(p2->getY());
    pp2[2] = *(p2->getZ());
    
    pcnt[0] = *(cnt->getX());
    pcnt[1] = *(cnt->getY());
    pcnt[2] = *(cnt->getZ());
    
    vl_result(pcnt,pp1,v1);
    vl_result(pcnt,pp2,v2);
    vl_result(pp1,pp2,v12);
    
    vl_scal(v1,v2,&vscal);

    a = acos(vscal/(vl_betrag(v1)*vl_betrag(v2)));
    dlv12 = 0;
    TColgp_Array1OfPnt pCloud(0,div);
    int counter =1;
    
    gp_Pnt pnt1(*(p1->getX()),*(p1->getY()),*(p1->getZ()));
    gp_Pnt pnt2(*(p2->getX()),*(p2->getY()),*(p2->getZ()));
    pCloud.SetValue(0,pnt1);
    pCloud.SetValue(div,pnt2);

    for(int i=1;i < div;i++)
    {
      dlv12 = (vl_betrag(v12)/div)*i;
      dlv12 /= vl_betrag(v12);
      vl_mult(&dlv12,v12,v12i);
      vl_add(pp1,v12i,piv);
      
      vl_result(pcnt,piv,vtmp);
      vl_scal(v1,vtmp,&vscali);
      ai = acos(vscali/(vl_betrag(v1)*vl_betrag(vtmp)));
      lengthi = (vl_betrag(v1)+ai/a*(vl_betrag(v2)-vl_betrag(v1)))/vl_betrag(vtmp);
      vl_mult(&lengthi,vtmp,vres);
      vl_add(pcnt,vres,piv);
      gp_Pnt pnt(piv[0],piv[1],piv[2]);
      pCloud.SetValue(counter,pnt);
      counter++;
    }
    curve = GeomAPI_PointsToBSpline(pCloud).Curve();
    myEdge = BRepBuilderAPI_MakeEdge(curve);
    myWire = BRepBuilderAPI_MakeWire(myEdge);
    WireFrameBuilder.Add(TestWire,myEdge);  
  }

  
  
    
/********** Class Line Arc End**************/
