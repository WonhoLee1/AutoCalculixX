#include <FbdReader.hxx>
#include <Seqa.hxx>

/************* Class Seqa *****************/
  Seqa :: Seqa(char * namei)
  {
    strcpy(name,namei);
    size=0;
  }
  
  void Seqa :: addPoint(Point* p)
  {
    myPoints.push_back(p);
    size++;
  }
  
  vector<Point*> * Seqa :: getPointVec()
  {
    return &myPoints;
  }
  
  char * Seqa :: getName()
  {
    return &name[0];
  }
  
  int * Seqa :: getSize(){	
    return &size;
  }
/************* Class Seqa End **************/