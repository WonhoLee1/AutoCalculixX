#include <FbdReader.hxx>
#include <Line.hxx>

/************** Class Line *****************/

  Line :: Line(char * namei)
  {
    strcpy(name,namei);
  }
  void Line :: setP1(Point * p){
    p1 = p;
  }
  
  void Line :: setP2(Point * p){
    p2 = p;
  }
  
  Point * Line :: getP1(){
    return p1;
  }
  
  Point * Line :: getP2(){
    return p2;
  }   
  
  void Line :: makeEdge(){
    cout<<"Make Edge: Line "<<name<<endl;
    TColgp_Array1OfPnt pCloud(0,1);
    gp_Pnt pnt1(*(p1->getX()),*(p1->getY()),*(p1->getZ()));
    gp_Pnt pnt2(*(p2->getX()),*(p2->getY()),*(p2->getZ()));
    
    pCloud.SetValue(0,pnt1);
    pCloud.SetValue(1,pnt2);
    curve = GeomAPI_PointsToBSpline(pCloud).Curve();
    myEdge = BRepBuilderAPI_MakeEdge(curve);
    myWire = BRepBuilderAPI_MakeWire(myEdge);
    WireFrameBuilder.Add(TestWire,myEdge);
  }    
  
/************ Class Line END ***************/
