#include <FbdReader.hxx>
#include <Util.hxx>

/**********************************************************/
/*    Vektorbetrag: C =  Vektor(B)-Vektor(A) == Vector(AB)*/
/**********************************************************/
void vl_result( double *A, double *B, double *C )
{
  register int i;

  for (i=0; i<3; i++)
	  C[i]=B[i]-A[i];
}

/*********************************************************/
/*    Vektormultiplikation: C = A x B                    */
/*********************************************************/
void vl_prod( double *A, double *B, double *C )
{
      C[0]=A[1]*B[2]-A[2]*B[1];
      C[1]=A[2]*B[0]-A[0]*B[2];
      C[2]=A[0]*B[1]-A[1]*B[0];
}

/*********************************************************/
/*    Scalar Product: C = A o B                   	 */
/*********************************************************/
void vl_sprod( double *A, double *B, double *C )
{
     *C=A[0]*B[0]+A[1]*B[1]+A[2]*B[2];
}

/*********************************************************/
/*         Vector(B)=Vektor(A)/|A|                       */
/*********************************************************/
double vl_norm( double *A, double *C )
{
  int i;
  double    B;

      B=0.;
      for ( i=0; i<3; i++)
       B=B+A[i]*A[i];

      B = sqrt(B);
      if(B==0.) {C[0]=C[1]=C[2]=0.; return(B);} 
      for ( i=0; i<3; i++)
       C[i]=A[i]/B;
      return(B);
}

/* ********************************************************* */
/*      laenge von Vektor a                                  */
/* ********************************************************* */
double vl_betrag(double *a)
{
  register int i;
  double b;
  b=0.;

  for (i=0; i<3; i++){
      b=b+a[i]*a[i];
   }
  b=sqrt(b);
  return(b);
}

/**********************************************************/
/* Vektormultiplikation:scalar(C) =  Vector(A)*Vektor(B) */
/**********************************************************/
void vl_scal( double *A, double *B, double *C )
{
  register int i;
  *C=0;
  for (i=0; i<3; i++){
         *C+= A[i] * B[i];
        }
}

/**********************************************************/
/* Vektormultiplikation: vektor(C) =  scalar(A)*Vektor(B) */
/**********************************************************/
void vl_mult( double *A, double *B, double *C )
{
  register int i;

  for (i=0; i<3; i++){
         C[i]= *A * B[i];
        }
}


/**********************************************************/
/*    Vektoraddition: C =  Vektor(B)+Vektor(A)            */
/**********************************************************/
void vl_add( double *A, double *B, double *C )
{
  register int i;

  for (i=0; i<3; i++){
         C[i]=B[i]+A[i];
        }
}

/**********************************************************/
/* Coordinate transformation	: A = M__ * P + t_ 	  */
/**********************************************************/
void vl_trans(double M [][3],double * t, double * P, double * A)
{
  int i,j;
  for(i=0;i<3;i++){
    A[i]=0;
    for(j=0;j<3;j++){
      A[i]=A[i]+M[i][j]*P[j];
    }  
  }
  vl_add(A,t,A);
}
