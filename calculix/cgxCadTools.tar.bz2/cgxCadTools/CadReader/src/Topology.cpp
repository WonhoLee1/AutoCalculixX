#include <CadReader.hxx>
#include <Topology.hxx>

/*********** Class Topology ****************/
/*************** Abstract ******************/

int * Topology :: getNumber(){
  return &number;
}

bool * Topology :: getFree(){ 
  return &free; 
}

void Topology :: setFree(bool f){ 
  free = f; 
}

/*********** Class Topology END ************/