#include <CadReader.hxx>

#include <stdlib.h>
#include <vector>

using namespace std;

fstream shortcut;
bool nurbs = false;
/*************************************/
/********* Menu Structure ************/
/*************************************/

void startScreen()
{
   cout<<"=============================================="<<endl;
   cout<<"*********      cad2fbd Converter     *********"<<endl;
   cout<<"=============================================="<<endl;  
}

void menuLoad(TopoDS_Shape * result)
{
  cout<<endl;
  int input;
  char *strTmp;
  char name [60];
  string line;
  int lineCount = 0, lineTarget;
  cout<<"***************************************"<<endl;
  cout<<"--------- Loading Options -------------"<<endl;
  cout<<"***************************************"<<endl;
  do{
    cout<<"[1] Load Step / IGES File"<<'\t'<<"[2] Load Shortcut"<<'\t'<<"[3] Add Shortcut"<<'\t'<<"[0] Next"<<endl;
    cin>>input; 
    switch(input)
    {
      case 1:
	cout<<"Enter File name:  filename.stp or filename.igs"<<endl;	
	cin>> name;
	loadStep(result,&name[0]);
	input = 0;
	break;
      case 2: 
	shortcut.open("shortcutList.txt",ios::in);
	cout<<"Choose a shortcut: "<<endl;
	lineCount = 0;
	while(getline (shortcut,line))//parse file linewise
	{
	  lineCount++;
	  cout<<"["<<lineCount<<"]  "<<line<<endl;
	}
	cin>>lineTarget;
	lineCount = 0;
	shortcut.clear();
	shortcut.seekg(0, ios::beg);
	while(getline (shortcut,line))//parse file linewise
	{
	  lineCount++;
	  if(lineTarget == lineCount) {
	    cout<<"load"<<endl;
	    strTmp = new char[line.length()+1];
	    strcpy(strTmp,line.c_str());
	    loadStep(result, &strTmp[0]); 
	  }
	}
	shortcut.close();
	input = 0;
	break;
      case 3:		
	cout<<"Enter File path/name or type del to delete list"<<endl;
	cin>>name;
	if(strcmp("del",name)==0){ 
	  shortcut.open("shortcutList.txt",ios::out | ios::trunc);
	}
	else {
	  shortcut.open("shortcutList.txt",ios::app);
	  shortcut<<name<<endl;
	}
	shortcut.close();
	break;
      case 0:
	cout<<"..."<<endl;
	break;
      default:
	cout<<"Chose one Menu Point"<<endl;
	break;
    }
  }while(input!=0);   
}

void menuConvert(TopoDS_Shape * result)
{
  cout<<endl;
  int input;
  Handle_ShapeBuild_ReShape rebuild = new ShapeBuild_ReShape;
  cout<<"***************************************"<<endl;
  cout<<"--------- Convert Options -------------"<<endl;
  cout<<"***************************************"<<endl;
 do{
    cout<<"[1] Split Shape"<<'\t'<<"[2] Convert to NURBS "<<'\t'<<"[0] Next"<<endl;
    cin>>input; 
    switch(input)
    {
      case 1:
	  int mode;
	  cout<<"[1] Complete Split"<<'\t'<<"[2] Closed Split"<<'\t'<<"[3] Only Conti Split"<<'\t'<<"[4] No Split"<<endl;
	  cin>>mode;
	  switch (mode)
	  {
	    case 1: healFace(result,true,true); break;
	    case 2: healFace(result,true,false); break;
	    case 3: healFace(result,false,true); break;
	    case 4: healFace(result,false,false); break;
	    default: cout<<"No Split"<<endl; break;
	  }	
	break;
      case 2: 
	   nurbs = true; 
	   cout<<"Nurbs Converion set------------"<<endl;
	break;
      case 0:
	cout<<"..."<<endl;
	break;
      default:
	cout<<"Chose one Menu Point"<<endl;
	break;
    }
  }while(input!=0);     
}

void menuTopology(TopoDS_Shape * result)
{
  char name [60];
  cout<<endl;
  int input;
  cout<<"***************************************"<<endl;
  cout<<"--------- Topology Options ------------"<<endl;
  cout<<"***************************************"<<endl;
   do{
    cout<<"[1] Init & Link Topology"<<'\t'<<"[2] Write fbd "<<'\t'<<"[3] Plot Topology Tree"<<'\t'<<"[0] Next"<<endl;
    cin>>input;   
    switch(input)
    {
      case 1:
	initTopology(result);
	linkTopoTree();
	if(nurbs) convert2Nurbs();
	break;
      case 2: 
	cout<<"Enter target File name [.fbd] : "<<endl;	
	cin>> name;
	drawTopology(name);
	break;
      case 3:		
	plotTopology();
	break;
      case 0:
	cout<<"..."<<endl;
	break;
      default:
	cout<<"Chose one Menu Point"<<endl;
	break;
    }
  }while(input!=0);    
}

void menuSave(TopoDS_Shape * result)
{
  cout<<endl;
  int input;
  char name [60];
  cout<<"***************************************"<<endl;
  cout<<"------------- Save Options ------------"<<endl;
  cout<<"***************************************"<<endl;
   do{
    cout<<"[1] Save"<<'\t'<<"[0] Quit"<<endl;
    cin>>input;   
    switch(input)
    {
      case 1:
	cout<<"Enter File name [.stp] : "<<endl;	
	cin>> name;
	saveStep(result,&name[0]);
	input = 0;
	break; 
      case 0:
	cout<<"Exit"<<endl;	
	break;
      default:
	cout<<"Chose one Menu Point"<<endl;
	break;
    }
  }while(input!=0);    
}