#include <CadReader.hxx>
#include <Surface.hxx>

//Disply Surface name and type 
#define PLOTTYPE 1
//Write Surface type as comment to fbd
#define TYPE2FBD 1

// If SCALEKNOTS == 1, the knot-spans of NURBS-Surfaces 
// are scaled to a parameter range of 0-1
#define SCALEKNOTS 1

// cones, spheres, cylinders and torodial shapes with a radius larger then the 
// model are regarded as degeneratedTol:
// larges allowed radius = refLength * factor
#define RELATIVE_CONE_SIZE 1.
#define RELATIVE_TORUS_SIZE 1.
#define RELATIVE_CYLINDER_SIZE 1.
#define RELATIVE_SPHERE_SIZE 1.

//*****************************************************************************************//
//If the Knot Vector contains knots that are too close together (Distance <= knotDiff),
//the parameter of one knode is increased by mDiv
//If this was not done, due to rounding errors the knots would be reagarded as a multiple knot
#define MDIV  0.00001
#define KNOT_DIFF  0.0000005
//*****************************************************************************************//

//****************************************//
//		Class Surface		  //
//****************************************//

//======================//
// 	Construktor	//
//======================//
Surface :: Surface( Handle(Geom_Surface) s,int n)
{
  surf = s;
  surfNurbs = NULL;
  number = n;
}

//======================================================================================//
//				Write Surface to fbd					//
//  NURBS, Planes, Cylinder, Planes, Shperes,Cones and Torodial Shapes are supportetd	//
//  The global variables usePln, useCyl,... set wich shapes elementary shapes		//
//  are to be converted to NURBS							//
//======================================================================================//
void Surface :: drawSurface()
{
   //write the surface type prior to NURBS converion as a comment 
  stringstream str;
  str.str(std::string());
  plotSurfaceType(str,false);
  
  #if TYPE2FBD == 1
    output<<"#Surface Type: "<<str.str()<<endl;
  #endif
  #if PLOTTYPE == 1
    cout<<"Surface ("<<number<<") Type: ";
  #endif
  
  bool drawNURBS = true,degenerated = false;
  if(surf->DynamicType() == STANDARD_TYPE(Geom_CylindricalSurface) && useCyl)//Cylindrical Surfaces
  {   
    #if PLOTTYPE == 1
      cout<<"Cylinder"<<endl;
    #endif
    GeomAdaptor_Surface adaptSurf =  GeomAdaptor_Surface (surf);  
    double radius;
    gp_Ax1 rotAxis; // Axis of the cylindrical surface
    
    if(adaptSurf.GetType()==GeomAbs_Cylinder)
    {
      gp_Cylinder myCyl = adaptSurf.Cylinder();
      rotAxis= myCyl.Axis();
      gp_Pnt origin =  myCyl.Location();
      gp_Dir aDir = rotAxis.Direction();
      radius = myCyl.Radius();	
      if(radius < refLength * RELATIVE_CYLINDER_SIZE)
      {
	output<<"PNT !cyd"<<number<<" "<<origin.X()<<" "<<origin.Y()<<" "<<origin.Z()<<endl;
	output<<"PNT !cyu"<<number<<" "<<origin.X()+aDir.X()<<" "<<origin.Y()+aDir.Y()<<" "<<origin.Z()+aDir.Z()<<endl;
	if(aliasing) output<<"SHPE !S"<<number<<" CYL %cyd"<<number<<" %cyu"<<number<<" "<<radius<<endl;
	else output<<"SHPE S"<<number<<" CYL %cyd"<<number<<" %cyu"<<number<<" "<<radius<<endl;
	drawNURBS = false;
      }
      else{
	degenerated = true;
      }	
    }
    if(degenerated)//convert conical surface to NURBS surface
    {
      output<<"#degenerated cylinder"<<endl;
      cout<<"degenerated cylinder -> converted to ";	
    }
  }
  else if(surf->DynamicType() == STANDARD_TYPE(Geom_Plane) && usePln)//Plane Surfaces
  {  
    #if PLOTTYPE == 1
      cout<<"Plane"<<endl;
    #endif
    GeomAdaptor_Surface adaptSurf =  GeomAdaptor_Surface (surf); 
    gp_Ax1 xAxis,yAxis;
    gp_Dir xDir,yDir;
    if(adaptSurf.GetType()==GeomAbs_Plane)
    {
      gp_Pln myPlane = adaptSurf.Plane();
      gp_Pnt origin =  myPlane.Location();
      xAxis = myPlane.XAxis();
      yAxis = myPlane.YAxis();
      xDir = xAxis.Direction();
      yDir = yAxis.Direction();
      output<<"PNT !po"<<number<<" "<<origin.X()<<" "<<origin.Y()<<" "<<origin.Z()<<endl;
      output<<"PNT !px"<<number<<" "<<origin.X()+xDir.X()<<" "<<origin.Y()+xDir.Y()<<" "<<origin.Z()+xDir.Z()<<endl;
      output<<"PNT !py"<<number<<" "<<origin.X()+yDir.X()<<" "<<origin.Y()+yDir.Y()<<" "<<origin.Z()+yDir.Z()<<endl;
      if(aliasing) output<<"SHPE !S"<<number<<" PLN %po"<<number<<" %px"<<number<<" %py"<<number<<endl;
      else output<<"SHPE S"<<number<<" PLN %po"<<number<<" %px"<<number<<" %py"<<number<<endl;
      drawNURBS = false;
    }
  }
  
  else if(surf->DynamicType() == STANDARD_TYPE(Geom_ConicalSurface) && useCon)//Cone Surfaces
  { 
    #if PLOTTYPE == 1
      cout<<"Cone: ";
    #endif
    GeomAdaptor_Surface adaptSurf =  GeomAdaptor_Surface (surf);    
    double radius1,radius2,height;
    gp_Dir aDir;
    gp_Ax1 rotAxis; // Axis of the cylindrical surface
    gp_Vec axis;
    if(adaptSurf.GetType()==GeomAbs_Cone)
    {
      gp_Cone myCone = adaptSurf.Cone();
      gp_Pnt top = myCone.Apex(); 
      gp_Pnt origin =  myCone.Location();
      rotAxis = myCone.Axis();
      radius1 = myCone.RefRadius();
      height = origin.Distance(top);
      if(height == 0) degenerated = true;
      else{
        axis =  gp_Vec(origin,top);
        aDir = gp_Dir(axis);
      }

      gp_Ax3 coordinates = myCone.Position();
      gp_Dir xDir = coordinates.XDirection();
      gp_Dir yDir = coordinates.YDirection();
      gp_Dir zDir = coordinates.Direction();
      /*
      output<<"X: "<<xDir.X()<<" "<<xDir.Y()<<" "<<xDir.Z()<<endl;
      output<<"Y: "<<yDir.X()<<" "<<yDir.Y()<<" "<<yDir.Z()<<endl;
      output<<"Z: "<<zDir.X()<<" "<<zDir.Y()<<" "<<zDir.Z()<<endl;
      output<<"Direct: "<<myCone.Direct()<<endl;
      output<<"Ori: "<<origin.X()<<" "<<origin.Y()<<" "<<origin.Z()<<endl;
      output<<"Top: "<<top.X()<<" "<<top.Y()<<" "<<top.Z()<<endl;
      output<<"Semi Angle: "<< myCone.SemiAngle()<<endl;
      */
      
      if(radius1 > refLength * RELATIVE_CONE_SIZE || radius1 == 0 || height == 0){//radius too large or zero  or zero height 
	degenerated = true;
      }
      else if(height > refLength)//cone with relatively too large hight
      {
	output<<"Cone with too large heigth was scaled"<<endl;
	cout<<"scaled too large cone"<<endl;
	axis.Normalize();
	axis.Scale(refLength/10);
	height = refLength/10; //set coner height to refLength/10
	radius2 = radius1-(tan(myCone.SemiAngle())*height);
	output<<"PNT !co"<<number<<" "<<origin.X()<<" "<<origin.Y()<<" "<<origin.Z()<<endl;
	output<<"PNT !ct"<<number<<" "<<origin.X()+axis.X()<<" "<<origin.Y()+axis.Y()<<" "<<origin.Z()+axis.Z()<<endl;
	if(aliasing) output<<"SHPE !S"<<number<<" CON %co"<<number<<" %ct"<<number<<" "<<radius1<<" "<<radius2<<endl;
	else output<<"SHPE S"<<number<<" CON %co"<<number<<" %ct"<<number<<" "<<radius1<<" "<<radius2<<endl; 
	drawNURBS = false;
      }
      else//regular cone
      {
	cout<<endl;
	output<<"PNT !co"<<number<<" "<<origin.X()<<" "<<origin.Y()<<" "<<origin.Z()<<endl;
	output<<"PNT !ct"<<number<<" "<<origin.X()+axis.X()<<" "<<origin.Y()+axis.Y()<<" "<<origin.Z()+axis.Z()<<endl;
	if(aliasing) output<<"SHPE !S"<<number<<" CON %co"<<number<<" %ct"<<number<<" "<<radius1<<" "<<0<<endl;
	else output<<"SHPE S"<<number<<" CON %co"<<number<<" %ct"<<number<<" "<<radius1<<" "<<0<<endl;     
	drawNURBS = false;
      }
      if(degenerated)//convert conical surface to NURBS surface
      {
	output<<"#degenerated cone"<<endl;
	cout<<"degenerated cone -> converted to ";	
      }
    }
  }
  
  else if(surf->DynamicType() == STANDARD_TYPE(Geom_SphericalSurface) && useSph)//Spherical Surfaces
  {
    #if PLOTTYPE == 1
      cout<<"Sphere"<<endl;
    #endif
    GeomAdaptor_Surface adaptSurf =  GeomAdaptor_Surface (surf);  
    double radius;
    gp_Ax1 rotAxis;
    gp_Ax3 coordinates;
    gp_Dir rotDir;
    
    if(adaptSurf.GetType()==GeomAbs_Sphere)
    {
       gp_Sphere mySphere = adaptSurf.Sphere();
       gp_Pnt origin  = mySphere.Location(); 
       coordinates = mySphere.Position();
       rotAxis = coordinates.Axis();
       rotDir = rotAxis.Direction();
       radius = mySphere.Radius();
       if(radius < refLength * RELATIVE_SPHERE_SIZE)
       {
        output<<"# sec Point: "<<rotDir.X()<<" "<<rotDir.Y()<<" "<<rotDir.Z()<<endl;
	output<<"PNT !so"<<number<<" "<<origin.X()<<" "<<origin.Y()<<" "<<origin.Z()<<endl;
	if(aliasing) output<<"SHPE !S"<<number<<" SPH %so"<<number<<" "<<radius<<endl;  
	else output<<"SHPE S"<<number<<" SPH %so"<<number<<" "<<radius<<endl; 
	drawNURBS = false;
       }
       else{
	degenerated = true;
       }
      if(degenerated)//convert conical surface to NURBS surface
      {
	output<<"#degenerated sphere"<<endl;
	cout<<"degenerated sphere -> converted to ";	
      }
    }
  }    
  else if(surf->DynamicType() == STANDARD_TYPE(Geom_ToroidalSurface) && useTor)//Toroidal Surface
  {
    #if PLOTTYPE == 1
      cout<<"Toroidal Surface"<<endl;
    #endif    
    GeomAdaptor_Surface adaptSurf =  GeomAdaptor_Surface (surf); 
    double radius1, radius2;
    gp_Ax1 rotAxis; // Axis of the torodial surface
    if(adaptSurf.GetType()==GeomAbs_Torus)
    {
       gp_Torus myTorus = adaptSurf.Torus();
       gp_Pnt origin  = myTorus.Location();  
       radius1 =  myTorus.MajorRadius();
       radius2 = myTorus.MinorRadius();
       if(radius1 > refLength * RELATIVE_TORUS_SIZE || radius2 >refLength) degenerated  = true;
       else{
	rotAxis= myTorus.Axis();
	gp_Dir aDir = rotAxis.Direction();
	output<<"PNT !td"<<number<<" "<<origin.X()<<" "<<origin.Y()<<" "<<origin.Z()<<endl;
	output<<"PNT !tu"<<number<<" "<<origin.X()+aDir.X()<<" "<<origin.Y()+aDir.Y()<<" "<<origin.Z()+aDir.Z()<<endl;
	if(aliasing) output<<"SHPE !S"<<number<<" TOR %td"<<number<<" "<<radius1<<" %tu"<<number<<" "<<radius2<<endl;
	else output<<"SHPE S"<<number<<" TOR %td"<<number<<" "<<radius1<<" %tu"<<number<<" "<<radius2<<endl;
	drawNURBS = false;
       }
    }
    if(degenerated)//convert conical surface to NURBS surface
    {
      output<<"#degenerated torus"<<endl;
      cout<<"degenerated torus -> converted to ";    
    }
  }
  if(drawNURBS)
  {
    if(!surfNurbs.IsNull()) 
    {
        #if PLOTTYPE == 1
	  cout<<"BSplineSurface"<<endl;
	#endif
	stringstream str;
	Handle(Geom_BSplineSurface) nSurf = GeomConvert::SurfaceToBSplineSurface(surfNurbs);
	nurbsSurface2fbd(nSurf,&number);       
    }
    else{
      cout<<"Empty Surface after Nurbs Conversion"<<endl;
    }  
  }
}

void Surface :: setNurbsSurface(Handle(Geom_Surface) nSurf)
{
  surfNurbs = nSurf;
}

//============================================//
//Write NURBS definition to fbd
//Knot-Vectors are scaled to a range of 0 - 1
//============================================//
void Surface :: nurbsSurface2fbd(Handle(Geom_BSplineSurface) nSurf,int *number)
{
  int myNbUPoles = nSurf->NbUPoles();
  int myNbVPoles = nSurf->NbVPoles();
  
  int myNbUKnots = nSurf->NbUKnots();
  int myNbVKnots = nSurf->NbVKnots();
    
  int uDeg = nSurf->UDegree(),vDeg = nSurf->VDegree();
  
  int nUKnotSeq = 0,nVKnotSeq = 0;
  
  //NUBRS-Knot-Spans are scaled to a parameter range of u=[0,1] and v=[0,1]
  double factorU,factorV;
  double refU = nSurf->UKnot(1);
  double refV = nSurf->VKnot(1);
  
  factorU = 1/(nSurf->UKnot(myNbUKnots)-nSurf->UKnot(1));
  factorV = 1/(nSurf->VKnot(myNbVKnots)-nSurf->VKnot(1));
  
  if(factorU < 0) factorU*=-1;
  if(factorV < 0) factorV*=-1;

  TColStd_Array1OfReal UK (1,myNbUKnots);
  TColStd_Array1OfReal VK (1,myNbVKnots);
  
  
  for(int u=1;u<=myNbUKnots;u++)
  {
    UK.SetValue(u,((nSurf->UKnot(u))-refU)*factorU);
    if(u>1 && (UK.Value(u)-UK.Value(u-1) != 0) && (UK.Value(u)-UK.Value(u-1) <= KNOT_DIFF))//Knot span too small
    {
      cout<<"small u-knot span ---> corrected"<<endl;
      UK.SetValue(u,UK.Value(u)+MDIV); 
      cout<<UK.Value(u)<<endl;
    }
    nUKnotSeq+=nSurf->UMultiplicity(u);
  }

  for(int v=1;v<=myNbVKnots;v++)
  { 
    VK.SetValue(v,((nSurf->VKnot(v))-refV)*factorV);
    if(v>1 && (VK.Value(v)-VK.Value(v-1) != 0) && (VK.Value(v)-VK.Value(v-1) <= KNOT_DIFF))//Knot span too small
    {
      cout<<"small v-knot span ---> corrected"<<endl;
      VK.SetValue(v,VK.Value(v)+MDIV);   
      cout<<VK.Value(v)<<endl;
    }
    nVKnotSeq+=nSurf->VMultiplicity(v);  
  }
  
 #if SCALEKNOTS == 1
 //Use Scaled Knot Spans
  nSurf->SetUKnots(UK);
  nSurf->SetVKnots(VK);
 #endif
  
 #if PLOTTYPE == 1
  //cout<<"VMultiplicity: "<<nSurf->VMultiplicity(1)<<endl;
  //cout<<"UMultiplicity: "<<nSurf->UMultiplicity(1)<<endl;  
  char name[9];
  if(aliasing) strcpy(name,"NURS %S");
  else strcpy(name,"NURS S");
  
  if(nSurf->IsUClosed()) cout<<"S "<<*number<<" is U Closed"<<endl;
  if(nSurf->IsVClosed()) cout<<"S "<<*number<<" is V Closed"<<endl;
 #endif
  if(aliasing)output<<"NURS !S"<<*number<< " DEFINE COMPACT "<<uDeg<<" "<<vDeg<<" "<<myNbUPoles<<" "<<myNbVPoles<<" "<<nUKnotSeq<<" "<<nVKnotSeq<<endl; 
  else output<<"NURS S"<<*number<< " DEFINE COMPACT "<<uDeg<<" "<<vDeg<<" "<<myNbUPoles<<" "<<myNbVPoles<<" "<<nUKnotSeq<<" "<<nVKnotSeq<<endl;
  for(int u=1;u<=myNbUPoles;u++)
  {
    for(int v=1;v<=myNbVPoles;v++)	
    {
	output<<name<<*number<<" CONTROL "<<u<<" "<<v<<" "<<(nSurf->Pole(u,v)).X()<<" "<<(nSurf->Pole(u,v)).Y()<<" "<<(nSurf->Pole(u,v)).Z()<<" "<<nSurf->Weight(u,v)<<endl;
    }
  }

  int index=1;
  for(int u=1;u<=myNbUKnots;u++)
  {	  
      for(int i=1;i<=nSurf->UMultiplicity(u);i++){
	output<<name<<*number<<" KNOT U "<<index<<" "<<nSurf->UKnot(u)<<" "<<endl;
	index++;
      }
  }
  index=1;
  for(int v=1;v<=myNbVKnots;v++)
  {	
      for(int i=1;i<=nSurf->VMultiplicity(v);i++){
      output<<name<<*number<<" KNOT V "<<index<<" "<<nSurf->VKnot(v)<<" "<<endl; 
      index++;
      }
  }
  output<<name<<*number<<" END"<<endl; 
}

//========================================//
//Write Surface Type to a stringstream
//========================================//
void Surface :: plotSurfaceType(stringstream &str,bool nurbs)
{
  Handle(Geom_Surface) s;
  if(nurbs) s = surfNurbs;
  else s = surf;
  if(! s.IsNull())
  {
    if(s->DynamicType() == STANDARD_TYPE(Geom_ConicalSurface)){
      str<<"ConicalSurface";
    } 
    else if(s->DynamicType() == STANDARD_TYPE(Geom_CylindricalSurface)){
      str<<"CylindricalSurface";    
    } 
    else if(s->DynamicType() == STANDARD_TYPE(Geom_Plane)){
      str<<"Plane"; 
    } 
    else if(s->DynamicType() == STANDARD_TYPE(Geom_SphericalSurface)){
      str<<"SphericalSurface"; 
    } 
    else if(s->DynamicType() == STANDARD_TYPE(Geom_ToroidalSurface)){
      str<<"ToroidalSurface"; 
    } 
    else if(s->DynamicType() == STANDARD_TYPE(Geom_SurfaceOfLinearExtrusion)){
      str<<"SurfaceOfLinearExtrusion"; 
    } 
    else if(s->DynamicType() == STANDARD_TYPE(Geom_SurfaceOfRevolution)){
      str<<"SurfaceOfRevolution"; 
    } 
    else if(s->DynamicType() == STANDARD_TYPE(Geom_BezierSurface)){
      str<<"BezierSurface"; 
    } 
    else if(s->DynamicType() == STANDARD_TYPE(Geom_BSplineSurface)){
      str<<"BSplineSurface"; 
    } 
    else if(s->DynamicType() == STANDARD_TYPE(Geom_RectangularTrimmedSurface)){
      str<<"RectangularTrimmedSurface"; 
    } 
    else {
      str<<"Unknown Surface";
    }    
  }
  else
  {
    str<<"NULL";
  }
}    

/****************************************/
