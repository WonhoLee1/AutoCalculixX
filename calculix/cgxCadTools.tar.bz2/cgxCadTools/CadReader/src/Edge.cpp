#include <CadReader.hxx>
#include <Edge.hxx>

/****************************************/
//Class Edge

    Edge :: Edge(TopoDS_Edge e,int n, bool s) 
    {
      myEdge = e;
      subElements=0;
      number = n;
      myCurve = new Curve(BRep_Tool::Curve(myEdge,c_start,c_end),number);
      free = true;
      seamEdge = s;
      
    };
    
    void Edge :: linkSubElements()
    {
      TopExp_Explorer e;
      for (e.Init(myEdge,TopAbs_VERTEX);e.More(); e.Next())
      {
	TopoDS_Vertex  veTemp = (TopoDS::Vertex (e.Current()));
	Vertex * v = (new Vertex(veTemp,false));
	vertexList.push_back(v);
	subElements++;
      }
    }
    
    vector<Vertex*> * Edge :: getVertexList()
    {
      return &vertexList;
    }
    
    void Edge :: write2fbd()
    {
      int err;
      err=myCurve->drawCurve(&split);
      if(err==0) status=true;
      else status = false;
    }
    
    void Edge :: plotTopoTree(stringstream & str)
    {
      str <<'\t'<<'\t'<<'\t'<<'\t'<<'\t'<<'\t'<<" | Edge "<<number<<" Type: ";
      myCurve->plotCurveType(str);
      str<<" ("<<subElements<<") | "<<'\n';
      for(std::vector<Vertex*>::iterator vei = vertexList.begin();vei != vertexList.end();++vei)
      {
	 (*vei)->plotTopoTree(str); 
      }      
    }
    
    void Edge :: convertNurbs()
    {
	Standard_Boolean status = false;
	myEdge = TopoDS::Edge(BRepBuilderAPI_NurbsConvert(myEdge,status));	
	myCurve->setCurve(BRep_Tool::Curve(myEdge,c_start,c_end));
    }
    
    TopoDS_Edge Edge :: getEdge()
    {
      return myEdge;
    }
       
    bool * Edge :: getSplit(){
      return &split;
    }
    
    void Edge :: setFree(bool f){
      free = f;
    }
    
    bool Edge :: getFree(){
      return free;
    }
    
    bool * Edge :: getStatus(){
      return &status;
    }
        
    void Edge :: setSeamEdge(bool s){
      seamEdge = s;
    }
    
    bool Edge :: getSeamEdge(){
      return seamEdge;
    }
/****************************************/