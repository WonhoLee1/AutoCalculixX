#include <CadReader.hxx>
#include <Compound.hxx>

/****************************************/
//Class Compound 

Compound :: Compound(TopoDS_Compound c,int n)
{
  myCompound = c;
  subElements = 0;
  number = n;
};

void Compound :: linkSubElements()
{
  TopExp_Explorer e;
  
  for(std::vector<CompSolid*>::iterator ci = freeCompSolid.begin();ci != freeCompSolid.end();++ci)
  {	  
    for (e.Init(myCompound,TopAbs_COMPSOLID);e.More(); e.Next())
    {  
      TopoDS_CompSolid  compTemp = (TopoDS::CompSolid (e.Current()));
      if(compTemp == (*ci)->getCompSolid())
      {
	compSolidList.push_back((*ci));
	(*ci)->setFree(false);
	subElements++;
      }	  
    }	
  }
}

std::vector<CompSolid*> * Compound :: getcompSolidList()
{
  return &compSolidList;
}

void Compound :: plotTopoTree(stringstream & str)
{
  str <<" | Compound"<<number<<"  ("<<subElements<<") | "<<'\n';
  for(std::vector<CompSolid*>::iterator ci = compSolidList.begin();ci != compSolidList.end();++ci)
  {
      (*ci)->plotTopoTree(str);
  }
}
    
/****************************************/
