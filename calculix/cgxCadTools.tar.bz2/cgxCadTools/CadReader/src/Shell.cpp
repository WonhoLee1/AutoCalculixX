#include <CadReader.hxx>
#include <Shell.hxx>

#define SHELL2BODY 1

/****************************************/
//Class Shell;

Shell :: Shell(TopoDS_Shell s,int n) 
{
  myShell = s;
  subElements=0;
  number = n;
  free = true;
};

void Shell :: linkSubElements()
{    
  TopExp_Explorer e;
  for(std::vector<Face*>::iterator ci = freeFace.begin();ci != freeFace.end();++ci)
  {	
    for (e.Init(myShell,TopAbs_FACE);e.More(); e.Next())
    { 
      TopoDS_Face faTemp = (TopoDS::Face (e.Current()));
      if(faTemp == (*ci)->getFace())
      {
	faceList.push_back((*ci));
	subElements++;
      }
    }
  }
}

std::vector<Face*> * Shell :: getFaceList()
{
  return &faceList;
}

void Shell :: plotTopoTree(stringstream & str)
{
  str <<'\t'<<'\t'<<'\t'<<" | Shell "<<number<<"  ("<<subElements<<") | "<<'\n';
  for(std::vector<Face*>::iterator fi = faceList.begin();fi != faceList.end();++fi)
  {
      (*fi)->plotTopoTree(str); 
      (*fi)->setFree(false);
  }      
}

void Shell :: write2fbd()
{
 #if SHELL2BODY == 1
  if(free)
  {
    int elementCounter = 0;
    output<<"GBOD B"<<number<< " NORM";
    for(std::vector<Face*>::iterator fi = faceList.begin();fi != faceList.end();++fi)
    {	
      if(elementCounter>=8)
      {
	elementCounter=0;
	output<<endl;
	output<<"GBOD B"<<number<< " ADD ";	    
      }
      if(*((*fi)->getStatus())){
	if(aliasing)  
	  output<<" + %A"<<*((*fi)->getNumber());
	else 
	  output<<" + A"<<*((*fi)->getNumber());
	elementCounter++;
      }  
    }	  
    output<<endl;
    output<<"SETA B"<<number<<" B"<<number<<endl;
    output<<"COMP B"<<number<<" do"<<endl;
  }
 #endif
}

TopoDS_Shell Shell :: getShell()
{
  return myShell;
}

/****************************************/

