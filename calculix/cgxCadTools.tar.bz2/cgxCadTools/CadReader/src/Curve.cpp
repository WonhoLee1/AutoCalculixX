#include <CadReader.hxx>
#include <Curve.hxx>

/****************************************/
//Class Curve

//======================//
// 	Construktor	//
//======================//
Curve :: Curve(Handle(Geom_Curve) c,int n)
{
    curve = c;
    number = n;
}

void Curve :: setCurve(Handle(Geom_Curve) c)
{
  curve = c;
}

//==============================================================//
// This function checkts if Geom_Curve object is a		//
// is a NULL pointer or a whether it is a closed curve. 	//	
// The Geom_Curve is converted to a Geom_BSplineCurve.		// 
// A closed curve is split a the pararmeter (uMax - uMin )/2.	//
// By calling nurbsLine2fbd, the curves are written to fbd	//
//==============================================================//
int Curve :: drawCurve(bool * split)
{
    int err=0;  
    if(! curve.IsNull())
    {
      if (curve->DynamicType() == STANDARD_TYPE(Geom_BSplineCurve)) {	
	//every Geom_Curve was previously converted to a BSpline in the function convertNurbs in the class Edge 
	//however with Brep_Tool, a general Geom_Curve object was retrieved from every edge
	//thus the GeomConvert command works as a cast in this context
	Handle(Geom_BSplineCurve) nCurve = GeomConvert::CurveToBSplineCurve(curve,Convert_QuasiAngular);
	
	if(nCurve->IsClosed ()==1)//closed curves are split, to avoid complications in cgx
	{
	  cout<<"Closed Edge "<<number<<" split"<<endl;
	  Standard_Boolean sameOrientation = true;
	  Standard_Real paramTolerance = gp::Resolution() *1.01;
	  Handle(Geom_BSplineCurve) nCurveI = GeomConvert::SplitBSplineCurve(nCurve,nCurve->FirstParameter(),nCurve->FirstParameter()+(nCurve->LastParameter()-nCurve->FirstParameter())/2,paramTolerance,sameOrientation);
	  Handle(Geom_BSplineCurve) nCurveII = GeomConvert::SplitBSplineCurve(nCurve,nCurve->FirstParameter()+(nCurve->LastParameter()-nCurve->FirstParameter())/2,nCurve->LastParameter(),paramTolerance,sameOrientation);
	  err += write2fbd(nCurveI,1);// to write each half of the curve to fbd, nurbsLine2fbd is called
	  err += write2fbd(nCurveII,2);// the, second pararmeter is:  1 -> curve was split - first half; 2 -> curve was split - second half
	  *split = true;//split status return to Edge object 
	  if(err==2) return 0;//error status returned to Edge object 
	  else return 1;
	}
	else
	{
	  err += write2fbd(nCurve,0);// the, second pararmeter is: 0 -> curve was not split
	  *split = false;
	  if(err==1) return 0;
	  else return 1;
	}
      } 
      else 
      {
	cout<<"No bSpline Curve found!"<<endl;
	return 1;
      }
    }
    else
    {
      cout<<"Curve Handle == NULL!"<<endl; 
      return 1;
    }
}
    
//==============================================================//
// With this function, the B-Spline representation of a 	//
// Geom_BSplineCurve object is written to the output file	//
// matching the syntax of the cgx NURL command			//
//==============================================================//    
int Curve :: write2fbd(Handle(Geom_BSplineCurve) nCurve, short split)
{
  Point* point1 = new Point(nCurve->StartPoint().X(),nCurve->StartPoint().Y(),nCurve->StartPoint().Z());
  Point* point2 = new Point(nCurve->EndPoint().X(),nCurve->EndPoint().Y(),nCurve->EndPoint().Z());
  int p1 = point1-> write2fbd();
  int p2 = point2-> write2fbd();
  int deg = nCurve->Degree();
  int nPoles = nCurve->NbPoles();
  int nKnots = nCurve->NbKnots();
  if(p1!=p2)//check if the line is degenerated 
  {
    int uKnotSeq=0;
    for(int i=1;i<=nKnots;i++)
    {
      uKnotSeq+=nCurve->Multiplicity(i);
    }
    stringstream name;
    if(split == 0) name<<"L"<<number;
    else if(split == 1) name<<"LI"<<number;//as a convetion, split lintes are called LI and LII 
    else name<<"LII"<<number;
    
    if(aliasing) output<<"NURL !"<<name.str()<<" DEFINE COMPACT"<<" %p"<<p1<<" %p"<<p2<<" "<<deg<<" "<<nPoles<<" "<<uKnotSeq<<endl;
    else output<<"NURL "<<name.str()<<" DEFINE COMPACT"<<" %p"<<p1<<" %p"<<p2<<" "<<deg<<" "<<nPoles<<" "<<uKnotSeq<<endl;
    for(int u=1;u<=nPoles;u++)
    {
	if(aliasing) output<<"NURL %"<<name.str()<<" CONTROL "<<u<<" "<<nCurve->Pole(u).X()<<" "<<nCurve->Pole(u).Y()<<" "<<nCurve->Pole(u).Z()<<" "<<nCurve->Weight(u)<<endl;
	else output<<"NURL "<<name.str()<<" CONTROL "<<u<<" "<<nCurve->Pole(u).X()<<" "<<nCurve->Pole(u).Y()<<" "<<nCurve->Pole(u).Z()<<" "<<nCurve->Weight(u)<<endl;
    }
    int index = 0;
    for(int u=1;u<=nKnots;u++)
    {
      for(int i=1;i<=nCurve->Multiplicity(u);i++)
      {
	index++;
	if(aliasing) output<<"NURL %"<<name.str()<<" KNOT "<<index<<" "<<nCurve->Knot(u)<<endl;
	else output<<"NURL "<<name.str()<<" KNOT "<<index<<" "<<nCurve->Knot(u)<<endl;
      }
    }
    if(aliasing)  output<<"NURL %"<<name.str()<<" END"<<endl; 
    else output<<"NURL "<<name.str()<<" END"<<endl; 
    name.flush();
    return 1;
  }
  else
  {
    cout<<"Small Line "<<number<<" merged"<<endl;
    return -1;
  }
}

//==============================================================//
// write the type of the Geom_Curve object to a stringstream	//
//==============================================================//    
void Curve :: plotCurveType(stringstream &str)
{
  if(! curve.IsNull())
  {
    if (curve->DynamicType() == STANDARD_TYPE(Geom_BezierCurve)) {
      str<<"BezierCurve";
    } 
    else if (curve->DynamicType() == STANDARD_TYPE(Geom_BSplineCurve)) {
      str<<"BSplineCurve";
    } 
    else if (curve->DynamicType() == STANDARD_TYPE(Geom_TrimmedCurve)) {
      str<<"TrimmedCurve";
    } 
    else if (curve->DynamicType() == STANDARD_TYPE(Geom_Circle)) {
      str<<"Circle";
    } 
    else if (curve->DynamicType() == STANDARD_TYPE(Geom_Ellipse)) {
      str<<"Ellipse";
    } 
    else if (curve->DynamicType() == STANDARD_TYPE(Geom_Hyperbola)) {
      str<<"Hyperbola";
    } 
    else if (curve->DynamicType() == STANDARD_TYPE(Geom_Parabola)) {
      str<<"Parabola";
    } 
    else if (curve->DynamicType() == STANDARD_TYPE(Geom_Line)) {
      str<<"Line";
    } 
    else if (curve->DynamicType() == STANDARD_TYPE(Geom_OffsetCurve)) {
      str<<"OffsetCurve";
    } 
    else {
      str<<"Unknown Curve";
    }
  }
  else
  {
    str<<"NULL";
  }
}   

/****************************************/

