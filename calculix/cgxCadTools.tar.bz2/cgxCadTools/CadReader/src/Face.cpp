#include <CadReader.hxx>
#include <Face.hxx>
#include <ShapeAnalysis_Wire.hxx>
//****************************************//
//		Class Face		  //
//****************************************//

//=======================================//
//Konstruktur
//=======================================//
Face :: Face(TopoDS_Face face,int n, Quantity_Color *col) 
{
  myFace = face;
  subElements=0;
  number = n;
  mySurface = new Surface(BRep_Tool::Surface(myFace),number);
  free = true;
  status = false;
  converted = false;
  myColor = *col;
};

//==========================================================//
//Search for boundary wires and store them in a vector List
//==========================================================//
void Face :: linkSubElements()
{
  TopExp_Explorer e;
  for (e.Init(myFace,TopAbs_WIRE);e.More(); e.Next())
  {
      for(std::vector<Wire*>::iterator ci = freeWire.begin();ci != freeWire.end();++ci)
      {	
      TopoDS_Wire wiTemp(TopoDS::Wire (e.Current()));
      if(wiTemp.IsEqual((*ci)->getWire()))
      {
	wireList.push_back((*ci));
	(*ci)->setFree(false);
	subElements++;
	break;
      }
    }
  }
}

//========================================================//
//Convert all Surfaces that are not of NURBS-Type to NURBS
//========================================================//
void Face :: convertNurbs()
{
  if((BRep_Tool::Surface(myFace))->DynamicType() != STANDARD_TYPE(Geom_BSplineSurface))
  {
    myFace = TopoDS::Face(BRepBuilderAPI_NurbsConvert(myFace,false));  
  }
  mySurface->setNurbsSurface(BRep_Tool::Surface(myFace));
  converted = true;
}


//========================================================//
//Write the face to fbd using the GSUR-Command
//Orientations of boundary-Wires are fully recovered 
//========================================================//
void Face :: write2fbd()
{  
  int trig = 0;
  int elementCounter=0, counter;
  
  //Write the underlying Surface of the Face to fbd  
  mySurface->drawSurface();

  //Recover Sign and Orientation of the Bounding Wire and write the Face to fbd
  //Orientation: 0=^ forward; 1=^ reversed 
 
  //Write GSUR Command and add a name 
  if(aliasing)  output<<"GSUR !A"<<number<<" + %S"<<number;
  else   	output<<"GSUR A"<<number<<" + S"<<number;

  for(std::vector<Wire*>::iterator wi = wireList.begin();wi != wireList.end();++wi)//Iterate through every boundary-Wire
  {
    /*
    TopoDS_Wire wTemp = (*wi)->getWire();
    ShapeAnalysis_Wire::ShapeAnalysis_Wire myAnalyse = ShapeAnalysis_Wire(wTemp, myFace,0.0001);
    myAnalyse.Perform ();
    myAnalyse.CheckSelfIntersection() ;
    */
    if(((*wi)->getWire()).Closed()==false) cout<<"Unclosed Loop"<<endl;
    vector<Edge*> edgeList = *((*wi)->getEdgeList());//Get Edges from a Wire
    vector<bool> edgeReversed = *((*wi)->edgeReversedList());//Orientations of shared Edges are recovered by this Vector
    counter = 0;
    //Wire Orientation determines the order of the stored Edges
    if((((*wi)->getWire()).Orientation())==1)//reversed case
    {
      for(std::vector<Edge*>::reverse_iterator edi = edgeList.rbegin();edi != edgeList.rend();++edi)//Iterate in reversed order
      {
	//Check if the Edge is reversed -> its Orientation differs form its curve 
	if(edgeReversed[edgeReversed.size()-counter-1]==true) trig = 1;
	else trig = 0; 

	if(*(*edi)->getStatus() == true)//Edge was valid -> no zero length Edge
	{
	  status = true;
	  if(*(*edi)->getSplit())//Dealing with closed Edges that were split
	  {
	    if(elementCounter>=8)
	    {
	      elementCounter=0;
	      output<<endl;
	      if(aliasing) output<<"GSUR %A"<<number<<" ADD";	
	      else output<<"GSUR A"<<number<<" ADD";	    
	    }
	    if(((**edi).getEdge()).Orientation()==trig){
	      if(aliasing){
		output<<" + %LI"<<*((*edi)->getNumber());	
		output<<" + %LII"<<*((*edi)->getNumber());
	      }
	      else{
		output<<" + LI"<<*((*edi)->getNumber());	
		output<<" + LII"<<*((*edi)->getNumber());		  
	      }
	    }
	    else{
	      if(aliasing){
		output<<" - %LII"<<*((*edi)->getNumber());	
		output<<" - %LI"<<*((*edi)->getNumber());  
	      }
	      else{
		output<<" - LII"<<*((*edi)->getNumber());	
		output<<" - LI"<<*((*edi)->getNumber());  		  
	      }
	    }
	    elementCounter+=2;
	  }
	  else//Dealing with Edges that were not split
	  {
	    if(elementCounter>=8)
	    {
	      elementCounter=0;
	      output<<endl;
	      if(aliasing) output<<"GSUR %A"<<number<<" ADD";	  
	      else output<<"GSUR A"<<number<<" ADD";	  	        
	    }
	    if(((**edi).getEdge()).Orientation()==trig){
		if(aliasing) output<<" + %L"<<*((*edi)->getNumber());	
		else output<<" + L"<<*((*edi)->getNumber());	
	    }
	    else{
		if(aliasing) output<<" - %L"<<*((*edi)->getNumber());	  
		else  output<<" - L"<<*((*edi)->getNumber());	 
	    }
	    elementCounter++;
	  }  
	}
	counter++;
      }      
    }  
    else//forward case
    {
      for(std::vector<Edge*>::iterator edi = edgeList.begin();edi != edgeList.end();++edi)//Iterate in forward order
      {
	//Check if the Edge is reversed -> its Orientation differs form its curve 
	if(edgeReversed[counter]==true) trig = 1;
	else trig = 0;
	
	if(*(*edi)->getStatus() == true)//Edge was valid -> no zero length Edge
	{
	  status = true;
	  if(*(*edi)->getSplit())//Dealing with closed Edges that were split
	  {
	    if(elementCounter>=8)
	    {
	      elementCounter=0;
	      output<<endl;
	      if(aliasing) output<<"GSUR %A"<<number<<" ADD";	    
	      else output<<"GSUR A"<<number<<" ADD";	
	    }
	    if(((**edi).getEdge()).Orientation()==trig){
	      if(aliasing) {
		output<<" + %LI"<<*((*edi)->getNumber());	
		output<<" + %LII"<<*((*edi)->getNumber());
	      }
	      else{
		output<<" + LI"<<*((*edi)->getNumber());	
		output<<" + LII"<<*((*edi)->getNumber());		
	      }
	    }
	    else
	    {
	      if(aliasing) {
		output<<" - %LII"<<*((*edi)->getNumber());	
		output<<" - %LI"<<*((*edi)->getNumber()); 
	      }
	      else{
		output<<" - LII"<<*((*edi)->getNumber());	
		output<<" - LI"<<*((*edi)->getNumber()); 		
	      }
	    }
	    elementCounter+=2;
	  }
	  else//Dealing with Edges that were not split
	  {
	    if(elementCounter>=8)
	    {
	      elementCounter=0;
	      output<<endl;
	      if(aliasing) output<<"GSUR %A"<<number<<" ADD";	   
	      else output<<"GSUR A"<<number<<" ADD";
	    }
	    if(((**edi).getEdge()).Orientation()==trig){
		if(aliasing) output<<" + %L"<<*((*edi)->getNumber());	
		else output<<" + L"<<*((*edi)->getNumber());
	    }
	    else{
		if(aliasing) output<<" - %L"<<*((*edi)->getNumber());
		else output<<" - L"<<*((*edi)->getNumber());
	    }
	    elementCounter++;
	  }  
	}
	counter++;
      }    
    }
  }    
  output<<endl;
  //stringstream str;
  //if(useXDE) writeColor2fbd(&myColor,str);
  //output<<str.str();
}

void Face :: writeColor2fbd(Quantity_Color *col,stringstream & str)
{ 
  int r,g,b;
  r = col->Red()*255;
  g = col->Green()*255;
  b = col->Blue()*255;
  if(aliasing) str<<"SETA "<<"r"<<r<<"g"<<g<<"b"<<b<<" s %A"<<number<<endl;
  else str<<"SETA "<<"r"<<r<<"g"<<g<<"b"<<b<<" s A"<<number<<endl;
}

std::vector<Wire*> * Face :: getWireList()
{
  return &wireList;
}

//=========================================//
//Add Face and Surface type to Topo Tree   // 
//=========================================//
void Face :: plotTopoTree(stringstream & str)
{
  str <<'\t'<<'\t'<<'\t'<<'\t'<<" | Face "<<number<<" Type: ";
  mySurface->plotSurfaceType(str,converted);
  str<<" ("<<subElements<<") | "<<'\n';
  for(std::vector<Wire*>::iterator wi = wireList.begin();wi != wireList.end();++wi)
  {
      (*wi)->plotTopoTree(str);
  }      
}

TopoDS_Face Face :: getFace()
{
  return myFace;
}

Surface * Face :: getSurface(){
  return mySurface; 
}

bool * Face :: getStatus(){
  return &status;
}

void Face :: setColor(Quantity_Color * col){
  myColor = *col;
}
    
Quantity_Color * Face :: getColor(){
  return &myColor;
}

    
/****************************************/
