#include <CadReader.hxx>
#include <Solid.hxx>

/****************************************/
//Class Solid;

Solid :: Solid(TopoDS_Solid s,int n, Quantity_Color *col) 
{
  mySolid = s;
  subElements=0;   
  number = n;
  free = true;
  myColor = *col;
};

void Solid :: linkSubElements()
{
  TopExp_Explorer e;
  for(std::vector<Shell*>::iterator ci = freeShell.begin();ci != freeShell.end();++ci)
  {	 
    for (e.Init(mySolid,TopAbs_SHELL);e.More(); e.Next())
    { 	
      TopoDS_Shell  sheTemp = (TopoDS::Shell (e.Current()));
      if(sheTemp == (*ci)->getShell())
      {
	shellList.push_back((*ci));
	(*ci)->setFree(false);
	subElements++;
      }
    }
  }
}

std::vector<Shell*> * Solid :: getShellList()
{
  return &shellList;
}

void Solid :: plotTopoTree(stringstream & str)
{
  str <<'\t'<<'\t'<<" | Solid "<<number<<"  ("<<subElements<<") | "<<'\n';
  for(std::vector<Shell*>::iterator si = shellList.begin();si != shellList.end();++si)
  {
      (*si)->plotTopoTree(str); 
  }      
}

void Solid :: write2fbd()
{    
  int elementCounter = 0;
  stringstream str;
  //cout<<"Body +"<<endl;
  output<<"GBOD B"<<number<< " NORM";
  TopoDS_Shape body;
  for(std::vector<Shell*>::iterator si = shellList.begin();si != shellList.end();++si)
  {
    vector<Face*> faceList = *((*si)->getFaceList());
    for(std::vector<Face*>::iterator fi = faceList.begin();fi != faceList.end();++fi)
    {	
      if(elementCounter>=8)
      {
	elementCounter=0;
	output<<endl;
	output<<"GBOD B"<<number<< " ADD ";	    
      }	
      //cout<<"Orientation"<<((**fi).getFace()).Orientation()<<endl;
      if(*((*fi)->getStatus())){
	if(aliasing) output<<" + %A"<<*((*fi)->getNumber());
	else output<<" + A"<<*((*fi)->getNumber());
	elementCounter++;
      }  
      (*fi)->writeColor2fbd(&myColor,str);
    }	  
  }
  output<<endl;
  output<<"SETA B"<<number<<" B B"<<number<<endl;
  output<<"COMP B"<<number<<" do"<<endl;
  output<<str.str();
}

TopoDS_Solid Solid :: getSolid()
{
  return mySolid;
}

void Solid :: setColor(Quantity_Color * col){
  myColor = *col;
}
    
Quantity_Color * Solid :: getColor(){
  return &myColor;
}


/****************************************/
