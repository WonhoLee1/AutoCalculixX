#include <CadReader.hxx>
#include <Vertex.hxx>

using namespace std;

/****************************************/
//Class Vertex;

Vertex :: Vertex(TopoDS_Vertex v,bool f) 
{
  myVertex = v;
  free = f;
};

void Vertex :: linkSubElements(){
  //empty
}
void Vertex :: plotTopoTree(stringstream & str)
{
  str <<'\t'<<'\t'<<'\t'<<'\t'<<'\t'<<'\t'<<'\t'<<" | Vertex |"<<'\n';   
}

TopoDS_Vertex Vertex :: getVertex()
{
  return myVertex;
}

/****************************************/