#include <CadReader.hxx>
#include <Wire.hxx>

/****************************************/
//Class Wire;

//======================//
//     constructor	//
//======================//
Wire :: Wire(TopoDS_Wire w,int n) 
{
  myWire = w;
  subElements=0;
  number=n;
  free = true;
};

//==============================================================//
// This function searches for Edge object in the vecotor list	// 
// freeEdge that contain TopoDS_Edge objects contained in the 	//
// myWire. Every matching Edge object is referenced in the 	//
// edgeList and its orientation is referenced seperatly in	//
// the list edgeReversed. That way, one shared Edge object can	//
// be referenced by multiple Wires. 				//
//==============================================================//

void Wire :: linkSubElements()
{
  TopExp_Explorer e;
  for (e.Init(myWire,TopAbs_EDGE);e.More(); e.Next())
  {
    for(std::vector<Edge*>::iterator ci = freeEdge.begin();ci != freeEdge.end();++ci)
    {
      if((*ci)->getSeamEdge()==true)
      {
	if(((*ci)->getEdge()).IsEqual(TopoDS::Edge(e.Current())))
	{
	  edgeReversed.push_back(false);
	  edgeList.push_back((*ci));
	  (*ci)->setFree(false);
	  subElements++;
	  break;
	}      
      }
      else
      {
	if(((*ci)->getEdge()).IsSame(TopoDS::Edge(e.Current())))
	{
	  if(((*ci)->getEdge()).IsEqual(TopoDS::Edge(e.Current())))
	    edgeReversed.push_back(false);
	  else 
	    edgeReversed.push_back(true);
	  
	  edgeList.push_back((*ci));
	  (*ci)->setFree(false);
	  subElements++;
	  break;
	}
      }
    }
  }
}

std::vector<Edge*> * Wire :: getEdgeList()
{
  return &edgeList;
}

std::vector<bool> * Wire :: edgeReversedList()
{
  return &edgeReversed;
}

int * Wire :: getSubElements()
{
  return &subElements;
}

void Wire :: plotTopoTree(stringstream & str)
{
  str <<'\t'<<'\t'<<'\t'<<'\t'<<'\t'<<" | Wire "<<number<<"  ("<<subElements<<") | "<<'\n';
  for(std::vector<Edge*>::iterator edi = edgeList.begin();edi != edgeList.end();++edi)
  {
      (*edi)->plotTopoTree(str); 
  }      
}
TopoDS_Wire Wire :: getWire()
{
  return myWire;
}


/****************************************/
