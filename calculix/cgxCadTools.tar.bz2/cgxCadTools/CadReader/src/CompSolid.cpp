#include <CadReader.hxx>
#include <CompSolid.hxx>

/****************************************/
//Class CompSolid;
CompSolid :: CompSolid(TopoDS_CompSolid c,int n)
{
  subElements=0;
  myCompSolid=c;
  number = n;
  free = true;
};

void CompSolid :: linkSubElements()
{
  TopExp_Explorer e;
  for(std::vector<Solid*>::iterator ci = freeSolid.begin();ci != freeSolid.end();++ci)
  {	 
    for (e.Init(myCompSolid,TopAbs_SOLID);e.More(); e.Next())
    {
      TopoDS_Solid  solTemp = (TopoDS::Solid (e.Current()));
      if(solTemp == (*ci)->getSolid())
      {
	solidList.push_back((*ci));
	(*ci)->setFree(false);
	subElements++;
      }
    }
  }
}

std::vector<Solid*> * CompSolid :: getSolidList()
{
  return &solidList;
}

void CompSolid :: plotTopoTree(stringstream & str)
{
  str <<'\t'<<" | CompSolid "<<number<<"  ("<<subElements<<") | "<<'\n';
  for(std::vector<Solid*>::iterator si = solidList.begin();si != solidList.end();++si)
  {
      (*si)->plotTopoTree(str); 
  }
}

TopoDS_CompSolid CompSolid :: getCompSolid()
{
  return myCompSolid;
}


/****************************************/
