//Standard C++ libraries
#include <iostream>
#include <stdlib.h>
#include <fstream>
#include <iomanip>

//Global variables are declared in this File
#define globalDefine

//Include Header File
#include <CadReader.hxx>

#define PLOTSPLIT 1
//Defines the number of Splitpoints for closed faces
#define NSPLITPNT 1
#define PLOT_XDE 0

#define DEFAULT_COL 0.3 

//Tolerance for Splitting discontinious Faces
#define tolConti 0.000001

using namespace std;

void displayColor(TopoDS_Shape *shape)
{
  Quantity_Color col;
  Handle(XCAFDoc_ColorTool) aColorTool = XCAFDoc_DocumentTool::ColorTool(myDoc->Main());
  if(!aColorTool.IsNull())
  {
    if (aColorTool->GetColor(*shape,XCAFDoc_ColorSurf ,col) || aColorTool->GetInstanceColor(*shape,XCAFDoc_ColorSurf ,col))
    {
      cout<<"ColorSurf";
      cout<<"RGB: "<<col.Red()*255<<" / "<<col.Green()*255<<" / "<<col.Blue()*255<<endl;
    }       
    else if(aColorTool->GetColor(*shape,XCAFDoc_ColorGen ,col) || aColorTool->GetInstanceColor(*shape,XCAFDoc_ColorGen ,col) )
    {
      cout<<"ColorGen";
    }
    else if(aColorTool->GetColor(*shape,XCAFDoc_ColorCurv ,col) || aColorTool->GetInstanceColor(*shape,XCAFDoc_ColorCurv ,col))
    {
      cout<<"ColorCurv";
    }
  }
}

//==============================================//
// explore the topology of a Root-Shape		//
// generate new objects from topology entyties	//
// store the objects in vector-lists 		// 
//==============================================//
void initTopology(TopoDS_Shape *shape)
{
     int counter;
     TopExp_Explorer e,f,g;
     Quantity_Color *col;
     
     TopoDS_Compound compTemp;
     TopoDS_CompSolid compsTemp;
     TopoDS_Solid solTemp;
     TopoDS_Shell sheTemp;
     TopoDS_Face faceTemp;
     TopoDS_Wire wirTemp;
     
     if(useXDE) Handle(XCAFDoc_ColorTool) aColorTool = XCAFDoc_DocumentTool::ColorTool(myDoc->Main());
     cout<<"Init Topology start------------------"<<endl;
     counter = 0;
     //Write Compounds to a Vector List
     for (e.Init(*shape,TopAbs_COMPOUND);e.More(); e.Next()){
        compTemp = TopoDS::Compound(e.Current());
	freeCompound.push_back(new Compound(compTemp,counter));	
	counter++;
     }
     counter = 0;
     //Write Comp Solids to a Vector List
     for (e.Init(*shape,TopAbs_COMPSOLID,TopAbs_COMPOUND);e.More(); e.Next()){   
        compsTemp = TopoDS::CompSolid(e.Current());
	freeCompSolid.push_back(new CompSolid(compsTemp,counter));
	counter++;;
     }
     counter = 0;
     //Write Solids to a Vector List
     for (e.Init(*shape,TopAbs_SOLID);e.More(); e.Next()){
        if(useXDE) col = solidColorList[counter];
        else col = new Quantity_Color(DEFAULT_COL,DEFAULT_COL,DEFAULT_COL,Quantity_TOC_RGB);
        solTemp = TopoDS::Solid(e.Current());
	freeSolid.push_back(new Solid(solTemp,counter,col));
      #if PLOT_XDE == 1 
        cout<<"Solid "<<counter;
        cout<<": RGB: "<<col->Red()*255<<" / "<<col->Green()*255<<" / "<<col->Blue()*255<<endl;
      #endif  
	counter++;
     }
     counter = 0;
     //Write Shells to a Vector List
     for (e.Init(*shape,TopAbs_SHELL);e.More(); e.Next()){
        sheTemp = TopoDS::Shell(e.Current());
	freeShell.push_back(new Shell(sheTemp,counter));
	counter++;
     }
     counter = 0;
     //Write Faces to a Vector List
     for (e.Init(*shape,TopAbs_FACE);e.More(); e.Next()){
        if(useXDE) col = faceColorList[counter];
        else col = new Quantity_Color(DEFAULT_COL,DEFAULT_COL,DEFAULT_COL,Quantity_TOC_RGB);
        faceTemp = TopoDS::Face(e.Current());
	freeFace.push_back(new Face(faceTemp,counter,col));
      #if PLOT_XDE == 1 
        cout<<"Face "<<counter;
        cout<<": RGB: "<<col->Red()*255<<" / "<<col->Green()*255<<" / "<<col->Blue()*255<<endl;
      #endif  
        counter++;
     }
     counter = 0;
     //Write Wires to a Vector List
     for (e.Init(*shape,TopAbs_WIRE);e.More(); e.Next()){
        wirTemp = TopoDS::Wire(e.Current());
	freeWire.push_back(new Wire(wirTemp,counter));		
	counter++;
     }
     counter = 0;
     //Write Edges to a Vector List
     bool merg,seamEdge;
     int faceEdges,shellEdges;
     for (f.Init(*shape,TopAbs_FACE);f.More(); f.Next())
     {
      faceEdges=0;
      for (e.Init(f.Current(),TopAbs_EDGE);e.More(); e.Next())
      {
	  merg=false;
	  seamEdge = false;
	  //Check if Edge is already in the freeEdge List
	  for(std::vector<Edge*>::iterator ci = freeEdge.begin();ci != freeEdge.end();++ci)
	  {	
	    if(((*ci)->getEdge()).IsSame(TopoDS::Edge(e.Current())))// same =^ equal in all but orientation
	    {
	      //found an Edge, that is identical, but has possibly a different orientation
	      if(ci >= (freeEdge.end())-faceEdges)
	      {
		//the Edge belongs to the same Face -> its a Seam Edge -> do not Merg!!!
		(*ci)->setSeamEdge(true);
		seamEdge = true;
	      }
	      else{
		merg = true;//the Edge is no Seam Edge, but a Shared Edge -> Merg !!!
	      }
	      break;
	    }
	    
	  }
	  if(merg == false){//Merg shared Edges -> one Edge will be referenced by two Faces 
	    freeEdge.push_back(new Edge(TopoDS::Edge(e.Current()),counter,seamEdge));	
	    counter++;
	    faceEdges++;
	  } 
      }
     }
     //save free Edges to the Vector List
     for (e.Init(*shape,TopAbs_EDGE,TopAbs_FACE);e.More(); e.Next()){
	freeEdge.push_back(new Edge(TopoDS::Edge(e.Current()),counter,seamEdge));	
	counter++;
     }
     cout<<"Init Topology end--------------------"<<endl;  
     //save free Edges to the Vector List
     for (e.Init(*shape,TopAbs_EDGE,TopAbs_FACE);e.More(); e.Next()){
	freeEdge.push_back(new Edge(TopoDS::Edge(e.Current()),counter,seamEdge));	
	counter++;
     }
     cout<<"Init Topology end--------------------"<<endl;  
}

//======================================================//
//   Link objects that are stored in the vector lists 	//
//======================================================//
void linkTopoTree()
{
  cout<<"Link Topo Tree start-----------------"<<endl;
  for(std::vector<Compound*>::iterator ci = freeCompound.begin();ci != freeCompound.end();++ci){	
    (*ci)->linkSubElements();
  }
  cout<<"Compund..Done"<<endl;
  for(std::vector<CompSolid*>::iterator ci = freeCompSolid.begin();ci != freeCompSolid.end();++ci){	
    (*ci)->linkSubElements();
  }
  cout<<"CompSolid..Done"<<endl;
  for(std::vector<Solid*>::iterator ci = freeSolid.begin();ci != freeSolid.end();++ci){	
    (*ci)->linkSubElements();
  }
  cout<<"Solid..Done"<<endl;
  for(std::vector<Shell*>::iterator ci = freeShell.begin();ci != freeShell.end();++ci){	
    (*ci)->linkSubElements();
  }
  cout<<"Shell..Done"<<endl;
  for(std::vector<Face*>::iterator ci = freeFace.begin();ci != freeFace.end();++ci){	
    (*ci)->linkSubElements();
  }
  cout<<"Face..Done"<<endl;
  for(std::vector<Wire*>::iterator ci = freeWire.begin();ci != freeWire.end();++ci){	
    (*ci)->linkSubElements();
  }
  cout<<"Wire..Done"<<endl;
  for(std::vector<Edge*>::iterator ci = freeEdge.begin();ci != freeEdge.end();++ci){	
    (*ci)->linkSubElements();
  }
  cout<<"Edge..Done"<<endl;
  cout<<"Link Topo Tree end-------------------"<<endl;
}


//======================================================//
//  Write geometry as fbd-commands to the output file 	//
//======================================================//
void drawTopology(const char * name)
{    
  output.open(&name[0]);
  cout<<"Wirte to fbd start-------------------"<<endl;
  //Writes every Edge of Topology, but only once
  for(std::vector<Edge*>::iterator ci = freeEdge.begin();ci != freeEdge.end();++ci){
    (*ci)->write2fbd();
  }
  //Writes every Nurbs of the Topology
  for(std::vector<Face*>::iterator ci = freeFace.begin();ci != freeFace.end();++ci){	
    (*ci)->write2fbd();
  }  
  //Writes every Body of the Topology
  for(std::vector<Solid*>::iterator ci = freeSolid.begin();ci != freeSolid.end();++ci){	
    (*ci)->write2fbd();
  }    
  //Writes free Shells as Bodies
  for(std::vector<Shell*>::iterator ci = freeShell.begin();ci != freeShell.end();++ci){	
    (*ci)->write2fbd();
  }  
  cout<<"Wirte to fbd end---------------------"<<endl;
}

//==============================================//
//    Dsiplay a tree of topological entities 	//
//==============================================//
void plotTopology()
{	
  cout<<"************************************"<<endl;
  cout<<"Plot Topo Tree start----------------"<<endl;
  stringstream str;
  for(std::vector<Compound*>::iterator ci = freeCompound.begin();ci != freeCompound.end();++ci){
    (*ci)->plotTopoTree(str);
  }
  cout<<"free Compounds: "<<endl;
  cout<<str.str()<<endl;
  str.str(std::string());

  for(std::vector<CompSolid*>::iterator ci = freeCompSolid.begin();ci != freeCompSolid.end();++ci){
    if(*((*ci)->getFree())==true)
      (*ci)->plotTopoTree(str);
  }
  cout<<"free CompSolids: "<<endl;
  cout<<str.str()<<endl;
  str.str(std::string());

  for(std::vector<Solid*>::iterator ci = freeSolid.begin();ci != freeSolid.end();++ci){
    if(*((*ci)->getFree())==true)
    (*ci)->plotTopoTree(str);
  }
  cout<<"free Solids: "<<endl;
  cout<<str.str()<<endl;
  str.str(std::string());

  for(std::vector<Shell*>::iterator ci = freeShell.begin();ci != freeShell.end();++ci){
    if(*((*ci)->getFree())==true)
    (*ci)->plotTopoTree(str);
  }
  cout<<"free Shell: "<<endl;
  cout<<str.str()<<endl;
  str.str(std::string());
  cout<<"Plot Topo Tree end------------------"<<endl;
  cout<<"************************************"<<endl;
}

void getExLineLength(TopoDS_Shape * shape, double *sum)
{
  TopExp_Explorer w,e;
  double length; 
  Standard_Real uStart, uEnd;
  Standard_Real c_start, c_end;
  *sum = 0;
  for (w.Init(*shape,TopAbs_WIRE);w.More(); w.Next())
  {
    for (e.Init(w.Current(),TopAbs_EDGE);e.More(); e.Next())
    {
      Handle_Geom_Curve curve =BRep_Tool::Curve(TopoDS::Edge(e.Current()),c_start, c_end);
      if(! curve.IsNull())
      {
	uStart = curve->FirstParameter();
	uEnd = curve->LastParameter();
	GeomAdaptor_Curve acurve(curve,uStart,uEnd);
	if (curve->DynamicType() == STANDARD_TYPE(Geom_Line)) {
	  GProp_GProps myProps;
	  BRepGProp::LinearProperties(e.Current(), myProps);
	  length = myProps.Mass();
	} 
	else{
	  length = GCPnts_AbscissaPoint::Length(acurve,uStart,uEnd);
	}
	*sum+=length;
      }
    }
  }
}

//========================================//
//Check whether NURB-surfaces are clamped //
//========================================//
bool validNurs(Handle(Geom_BSplineSurface) nSurf)
{
  int uDeg = nSurf->UDegree(),vDeg = nSurf->VDegree();
  if(nSurf->UMultiplicity(1)==(uDeg+1) && nSurf->UMultiplicity(nSurf->NbUKnots())==(uDeg+1) && nSurf->VMultiplicity(1)==(vDeg+1) && nSurf->VMultiplicity(nSurf->NbVKnots())==(vDeg+1)){return true;}
  else  {
    return false;}
}
//=======================================================//
//Perform shape-healing and surface splitting operations //
//=======================================================//
bool healFace(TopoDS_Shape *shape,bool splitClose,bool splitConti)
{
    Handle_ShapeBuild_ReShape rebuild = new ShapeBuild_ReShape;  
    cout<<"Heal Face start----------------------"<<endl;
    cout<<"Divide Closed start -----------------"<<endl;
    TopoDS_Shape tmp = *shape;
    TopExp_Explorer e;
    int faceCounter =0,splitCounter=0;
    bool done = false;   
    while(!done && splitClose)
    {
      faceCounter = 0;
      for (e.Init(*shape,TopAbs_FACE);e.More(); e.Next())
      {    	
	if(faceCounter == splitCounter)
	{
          ShapeUpgrade_ShapeDivideClosed splitClosedTool (TopoDS_Shape(e.Current()));
          Handle(ShapeBuild_ReShape) Context = new ShapeBuild_ReShape;
          splitClosedTool.SetContext(Context);
          splitClosedTool.SetNbSplitPoints(NSPLITPNT);
          Standard_Boolean reset = false;
          splitClosedTool.Perform(reset);
          if(splitClosedTool.Status (ShapeExtend_DONE2))
          {	              
            tmp = Context->Apply(tmp);
          #if PLOTSPLIT == 1 
            cout<<"Splitting Closed Face "<<splitCounter<<": Done"<<endl;
          #endif
            if(useXDE){//Give every Face, that resulted from a splitting operation the color of its parent
              vector<Quantity_Color*>::iterator it;
              TopoDS_Shape tmpResult = Context->Apply(e.Current());
              TopExp_Explorer f;
              f.Init(tmpResult,TopAbs_FACE);
              for(f.Next();f.More();f.Next()){
                it = faceColorList.begin();
                faceColorList.insert(it+splitCounter,faceColorList[splitCounter]);
              }    
            }
          }
	}
	faceCounter++;
      }
      if(splitCounter>faceCounter-1) done = true;
      *shape = tmp;
      splitCounter++;
    }
    cout<<"Divide Closed end -------------------"<<endl;

    cout<<"Divide Conti start ------------------"<<endl;
    if(checkNURBS == true){
      tmp = *shape;
      faceCounter =0;
      splitCounter=0;
      done = false;
      bool valid;
      while(!done)
      {
	faceCounter =0;      
	for (e.Init(*shape,TopAbs_FACE);e.More(); e.Next())
	{    
	  valid = true;
	  TopoDS_Face myFace = TopoDS::Face(e.Current());
	  Handle(Geom_Surface) c = BRep_Tool::Surface(myFace);
	  
	  if(! c.IsNull() && faceCounter == splitCounter)
	  {
	    if (c->DynamicType() == STANDARD_TYPE(Geom_BSplineSurface)) 
	    {
	      Handle(Geom_BSplineSurface) nSurf = GeomConvert::SurfaceToBSplineSurface(c);
	      valid = validNurs(nSurf); 
	    }	
	  }	
	  if(faceCounter == splitCounter && (splitConti == true || valid == false))//Split Only Unvalid NURBS if noSplitConti is set
	  {
	    if(!valid){
	    #if PLOTSPLIT == 1 
	      cout<<"Face "<<splitCounter<<" Invalid"<<endl;
	      #endif
	    }
            ShapeUpgrade_ShapeDivideContinuity splitContiTool (TopoDS_Shape(e.Current()));
            Handle(ShapeBuild_ReShape) Context = new ShapeBuild_ReShape;
            splitContiTool.SetContext(Context);
            splitContiTool.SetTolerance(tolConti);
            splitContiTool.SetSurfaceCriterion (GeomAbs_C1);
            Standard_Boolean reset = false;
            splitContiTool.Perform(reset);
            if(splitContiTool.Status (ShapeExtend_DONE2))
            {	
              tmp = splitContiTool.GetContext()->Apply(tmp);
              if(useXDE){//Give every Face, that resulted from a splitting operation the color of its parent 
                vector<Quantity_Color*>::iterator it;
                TopoDS_Shape tmpResult = Context->Apply(e.Current());
                TopExp_Explorer f;
                f.Init(tmpResult,TopAbs_FACE);
                for(f.Next();f.More();f.Next()){
                  it = faceColorList.begin();
                  faceColorList.insert(it+splitCounter,faceColorList[splitCounter]);
                }    
              }
            #if PLOTSPLIT == 1
              cout<<"Splitting C1 Discontinious Face "<<splitCounter<<" : Done"<<endl;
            #endif
            }
            else if(!valid)
            {
            #if PLOTSPLIT == 1
              cout<<"Face "<<splitCounter<<" : NOT Done"<<endl;
            #endif
              splitContiTool.SetSurfaceCriterion (GeomAbs_C2);
              Standard_Boolean reset = false;
              splitContiTool.Perform(reset);
              if(splitContiTool.Status (ShapeExtend_DONE2))
              {	
                tmp = splitContiTool.GetContext()->Apply(tmp);
                if(useXDE){//Give every Face, that resulted from a splitting operation the color of its parent 
                  vector<Quantity_Color*>::iterator it;
                  TopoDS_Shape tmpResult = Context->Apply(e.Current());
                  TopExp_Explorer f;
                  f.Init(tmpResult,TopAbs_FACE);
                  for(f.Next();f.More();f.Next()){
                    it = faceColorList.begin();
                    faceColorList.insert(it+splitCounter,faceColorList[splitCounter]);
                  }    
                }
              #if PLOTSPLIT == 1
                cout<<"Splitting C2 Discontinious Face "<<splitCounter<<" : Done"<<endl;
              #endif 
              }	    
            }      
	  }
	  faceCounter++;
	}
	if(splitCounter>=faceCounter-1) done = true;
	*shape = tmp;
	splitCounter++;
      }
      *shape = tmp;
    }
    cout<<"Divide Conti end --------------------"<<endl;

    cout<<"Heal Face end------------------------"<<endl;
    
    cout<<"Fix Face start-----------------------"<<endl;

   Handle(ShapeFix_Shape) sfs = new ShapeFix_Shape; 
   sfs->Init ( *shape);
   //sfs->SetPrecision (0.00000001); 
   //sfs->SetMaxTolerance (10);
   sfs->Perform();   
   *shape = sfs->Shape(); 
   
   
   Handle(ShapeFix_Wireframe) SFWF = new ShapeFix_Wireframe(*shape);  
   //sfs->SetPrecision   (0.00000001 );  
   //sfs->SetMaxTolerance(10);  
   SFWF->ModeDropSmallEdges() = Standard_True;  
   SFWF->FixSmallEdges(); 
   SFWF->FixWireGaps();  
   *shape= SFWF->Shape(); 
   
    cout<<"Fix Face end-------------------------"<<endl;
    
   //Return if Splitting was done
   if(done) return true;
   else return false;      
}

//==============================================//
// Read STEP file "name" and safe it as a shape	//
//==============================================//
bool loadStep(TopoDS_Shape *shape, char * name)
{
  bool step,status = false;
  STEPControl_Reader sReader; 
  IGESControl_Reader iReader;
  STEPCAFControl_Reader xsReader; //STEP reader for Extended Data Exchange (XDE)
  IGESCAFControl_Reader xiReader; //STEP reader for Extended Data Exchange (XDE)  
  xsReader.SetColorMode(true);
  xsReader.SetLayerMode(true);
  xiReader.SetColorMode(true);
  xiReader.SetLayerMode(true); 
  
  if(strstr(name,".stp")!=NULL || strstr(name,".step")!=NULL || strstr(name,".STEP")!=NULL){
    cout<<"Loading STEP File: "<< name <<endl;
    step = true;
  } 
  else if(strstr(name,".igs")!=NULL || (strstr(name,".iges")!=NULL)){
    cout<<"Loading IGES File: "<< name <<endl;
    step = false;
  }
  else
  {
    cout<<"Neither .stp .step nor .igs file found!"<<endl;
    return false;
  }
    cout<<"Load start---------------------------"<<endl;
  if(useXDE)
  {
    if(step)
    {
      IFSelect_ReturnStatus readstat = xsReader.ReadFile(name);
      if(readstat == IFSelect_RetDone && useXDE) 
      {
        cout<<"XDE reading success"<<endl;
        cout<<"Roots: "<<xsReader.NbRootsForTransfer ()<<endl;
        Handle(XCAFApp_Application) anApp = XCAFApp_Application::GetApplication();
        anApp->NewDocument("MDTV-XCAF", myDoc);
        
        if (!xsReader.Transfer(myDoc)) { 
          cout<<"XDE STEP transfer failed!"<<endl;
          return 0;
        }   
      }
      else{
        cout<<"no XDE reading --> use STEPCAFControl_Reader"<<endl;
        useXDE = false;
      }
    }
    else
    {
      IFSelect_ReturnStatus readstat = xiReader.ReadFile(name);
      if(readstat == IFSelect_RetDone && useXDE) 
      {
        cout<<"XDE reading success"<<endl;
        cout<<"Roots: "<<xiReader.NbRootsForTransfer ()<<endl;
        Handle(XCAFApp_Application) anApp = XCAFApp_Application::GetApplication();
        anApp->NewDocument("MDTV-XCAF", myDoc);
        
        if (!xiReader.Transfer(myDoc)) { 
          cout<<"XDE STEP transfer failed!"<<endl;
          return 0;
        } 
      }
      else{
        cout<<"no XDE reading --> use IGESCAFControl_Reader"<<endl;
        useXDE = false;
      }
    }    
    
    if(useXDE) //transfer was successfull <=> useXDE is still true
    {
      cout<<"XDE transfer successfull"<<endl;
      Handle(XCAFDoc_ShapeTool) aShapeTool = XCAFDoc_DocumentTool::ShapeTool(myDoc->Main());
      TDF_LabelSequence labelSequ;
      aShapeTool->ComputeSimpleShapes();
      aShapeTool->GetFreeShapes(labelSequ);//label Sequ contains all free shapes (roots)
      cout<<"Shapes: "<<labelSequ.Length()<<endl;
    
      Quantity_Color col; 
      Handle(XCAFDoc_ColorTool) aColorTool = XCAFDoc_DocumentTool::ColorTool(myDoc->Main());
      
      TopExp_Explorer e,k;
      BRep_Builder myCompoundBuilder;
      TopoDS_Compound Result;
      
      myCompoundBuilder.MakeCompound(Result);
      
      cout<<"Color list---------------------------"<<endl;
      cout<<"Colors used in the Model"<<endl;
      TDF_LabelSequence colorsUsed;
      aColorTool->GetColors(colorsUsed);
      for(int i=1;i<=colorsUsed.Length();i++)
      {
        if(aColorTool->GetColor(colorsUsed.Value(i),col))
          cout<<col.Red()*255<<" / "<<col.Green()*255<<" / "<<col.Blue()*255<<endl;
      }
      cout<<"End Color list-----------------------"<<endl;
      for(int i=1;i<=labelSequ.Length();i++)
      {
        TopoDS_Shape aShape = aShapeTool->GetShape(labelSequ.Value(i));
        myCompoundBuilder.Add(Result,aShapeTool->GetShape(labelSequ.Value(i)));
        
        for(k.Init(aShape,TopAbs_SOLID);k.More();k.Next())
        {
          TopoDS_Solid tmpSolid = TopoDS::Solid(k.Current());  
          if(!aColorTool.IsNull())
          {
            if (aColorTool->GetColor(tmpSolid,XCAFDoc_ColorSurf,col) || aColorTool->GetColor(tmpSolid,XCAFDoc_ColorCurv,col) || aColorTool->GetColor(tmpSolid,XCAFDoc_ColorGen,col)|| aColorTool->GetInstanceColor(k.Current(),XCAFDoc_ColorSurf ,col)){
              solidColorList.push_back(new Quantity_Color(col.Red(),col.Green(),col.Blue(),Quantity_TOC_RGB));
            }      
            else{
              solidColorList.push_back(new Quantity_Color(DEFAULT_COL,DEFAULT_COL,DEFAULT_COL,Quantity_TOC_RGB));
            }
          }
        }
        
        for (e.Init(aShape,TopAbs_FACE);e.More(); e.Next())
        {
          TopoDS_Face tmpFace = TopoDS::Face(e.Current());
          if(!aColorTool.IsNull())
          {
            if (aColorTool->GetColor(tmpFace,XCAFDoc_ColorSurf ,col) || aColorTool->GetInstanceColor(e.Current(),XCAFDoc_ColorSurf ,col)){
              faceColorList.push_back(new Quantity_Color(col.Red(),col.Green(),col.Blue(),Quantity_TOC_RGB));
            }      
            else{
              faceColorList.push_back(new Quantity_Color(DEFAULT_COL,DEFAULT_COL,DEFAULT_COL,Quantity_TOC_RGB));
            }
          }
          else{
            faceColorList.push_back(new Quantity_Color(DEFAULT_COL,DEFAULT_COL,DEFAULT_COL,Quantity_TOC_RGB));
          }
        }
      }

      if(Result.IsNull()){ 
        cout<<"empty labelSequence ... error while loading in XDE-mode"<<endl;  
      }
      else {
        (*shape) = Result;
        return true;
      }        
    }
  } 
  
  
  if(step && !useXDE)
  {
    if(sReader.ReadFile(name) == IFSelect_RetError)
    {
      cout<<"STEP File "<<name<<" does not exist!"<<endl;
      status = false;
    }
    else
    {
      Standard_Integer NbRoots = sReader.NbRootsForTransfer(); 
      // gets the number of transferable roots   
      cout<<"Number of roots in STEP file: "<< NbRoots<<endl;    
      Standard_Integer NbTrans = sReader.TransferRoots();   
      // translates all transferable roots, and returns the number of   
      //successful translations    
      cout<<"STEP roots transferred: "<< NbTrans<<endl;    
      cout<<"Number of resulting shapes is: "<<sReader.NbShapes()<<endl;    
      (*shape) = sReader.OneShape();    
      if(sReader.NbShapes()>0) {
        cout<<"Loading successfully finished "<<endl;
        status = true;
      }
      else{
        cout<<"No Shape found. Loading Failed!"<<endl;
        status = false;
      }
    }
  }
  else if(!useXDE)
  {
    if(iReader.ReadFile(name) == IFSelect_RetError)
    {
      cout<<"IGES File "<<name<<" does not exist!"<<endl;
      status = false;
    }
    else
    {
      Standard_Integer NbRoots = iReader.NbRootsForTransfer(); 
      // gets the number of transferable roots   
      cout<<"Number of roots in IGES file: "<< NbRoots<<endl;    
      Standard_Integer NbTrans = iReader.TransferRoots();   
      // translates all transferable roots, and returns the number of   
      //successful translations    
      cout<<"IGES roots transferred: "<< NbTrans<<endl;    
      cout<<"Number of resulting shapes is: "<<iReader.NbShapes()<<endl;    
      (*shape) = iReader.OneShape();    
      if(iReader.NbShapes()>0){
	cout<<"Loading successfully finished "<<endl;
	status = true;
      }
      else{
	cout<<"No Shape found. Loading Failed!"<<endl;
	status = false;
      }
    }  
  }
  cout<<"Load end-----------------------------"<<endl;
  return status;
}

//======================================//
//    Save shape as Step File "name"	//
//======================================//
void saveStep(TopoDS_Shape * shape,const char * name)
{
  cout<<"Save start---------------------------"<<endl;
  if(!(*shape).IsNull())
  {
    STEPControl_Writer writer;
    writer.Transfer(*shape,STEPControl_AsIs);
    writer.Write(name); 
    cout<<"Saving "<<name<<" successfully finished!"<<endl;
  }
  else
  {
    cout<<"Empty shape. Saving Failed!"<<endl;
  }
  cout<<"Save end-----------------------------"<<endl;
}

//==============================================//
//  call BRepBuilderAPI_NurbsConvert for every	//
//  Edge and Face to convert the underlying	//
//  geometry to NURBS representation		//
//==============================================//
void convert2Nurbs()
{
  cout<<"NURBS Conversion start---------------"<<endl;  
  cout<<"Convert Surfaces..."<<endl;
  for(std::vector<Face*>::iterator ci = freeFace.begin();ci != freeFace.end();++ci){	
    (*ci)->convertNurbs();

  }
  cout<<"...done"<<endl;
  cout<<"Convert Curves..."<<endl;
  for(std::vector<Edge*>::iterator ci = freeEdge.begin();ci != freeEdge.end();++ci){	
    (*ci)->convertNurbs();  
  }
  cout<<"...done"<<endl;
  cout<<"NURBS Conversion end-----------------"<<endl;
}

//==============================================//
//  start screen for informative purposes	//
//==============================================//
void infoDisplay()
{
   cout<<"A STEP/IGES to fbd converter for the Finite Element Software CalculiX"<<endl;
   cout<<"Version 1.2 - 28 March 2017\n"<<endl;
   cout<<"by Pascal Mossier"<<'\n'<<endl;
   
   printf("usage: cad2fbd [parameter] filename \n\n");   
   printf("Parameter:\n");
   printf("Flags for Surface Splitting:\n");
   printf("\t if no flag is set, cad2fbd uses -ns as a default\n");   
   printf("\t'-scl' -> split closed surfaces\n");
   printf("\t'-sco' -> split discontinious surfaces (C1-continiuity demanded)\n");
   printf("\t'-ns'  -> no splitting; correct only NURBS that would be invalid in cgx (multiplicity = degree+1) \n");
   printf("\t'-sa'  -> use all creteria to split surfaces (continiuity and closed)\n\n");
   printf("Flags for Geometry Conversion:\n");
   printf("\t'-pln' -> convert planes to NURBS surfaces\n");
   printf("\t'-cyl' -> convert cylinders to NURBS surfaces\n");
   printf("\t'-con' -> convert cones to NURBS surfaces\n");
   printf("\t'-sph' -> convert spheres to NURBS surfaces\n");
   printf("\t'-tor' -> convert torodial shapes to NURBS surfaces\n\n");
   printf("Additional Flags:\n");
   printf("\t'-xde'-> load CAD-file with Face colors using Extended Data Exchange. Creates a set for every Color e.g. set 25500 that containes every face with the color RGB: 255 0 0 \n");
   printf("\t'-m'  -> run the programm in a Menu-Mode (only as first Parameter)\n");   
   printf("\t'-v'  -> display the Topology Tree\n");
   printf("\t'-nch'-> do not check whether NURBS are clamped -> speed up conversion of very large models (works only if NURBS are already correct)\n");   
   printf("\t'-nal'-> deactivate entity names aliasing\n");   
   printf("\t'-ex' -> export the STEP file after splitting and NURBS conversion\n"); 
   printf("\t'-tolM' -> change tolerance for merging points. Example: -tolM 0.001\n\n"); 
   printf("The result is saved as result.fbd\n");
}

int main(int argc,char* argv[])
{ 
  startScreen();
  TopoDS_Shape result,splitResult,nurbs_result;
  usePln = useCyl = useCon = useSph = useTor = true;//use primitive shapes by default 
  bool  splitConti=false, splitClose = false, topoVis=false,save =false,nConvert = false,fbdConv = false;
  aliasing = true;//As default, entitiy names are set by CalculiX
  checkNURBS = true;
  useXDE = false;
  refLength = -1;
  tolMergPoints = 0.001;// default point merging tolerance
  XCAFDoc_ColorTool aColorTool;
  
  if(argc <=1) //Menu Mode
  {  
    infoDisplay();
  }
  else if(argc == 2 && strcmp(argv[1],"-m")==0)
  {
    cout<<"--> Running cad2fbd in Menu Mode <--"<<endl;
    menuLoad(&result);
    menuConvert(&result);
    menuTopology(&result);
    menuSave(&result);  
  }
  else //Flag Mode
  {
    cout<<"--> Running cad2fbd in Flag Mode <--"<<endl;
    char * loadName;
    
    //default flags
    splitClose = false;
    splitConti = false;
    fbdConv = true;	
    nConvert = true;

    //Save the last Argument as the filename
    loadName = argv[argc-1];
    //search for flags
    for(int i=1;i<argc;i++)
    {
	//**** splitting flags *****//
	if(strcmp(argv[i],"-scl")==0){//Splitting of closed Faces  
	  splitClose = true;
	}
	else if(strcmp(argv[i],"-sco")==0){//Splitting of discontinious Faces
	  splitConti = true;
	}
	else if(strcmp(argv[i],"-ns")==0){//No Splitting
	  splitClose = false;
	  splitConti = false;
	}
	else if(strcmp(argv[i],"-sa")==0){//Splitting with both criteria
	  splitConti = true;
	}	
	
	//**** geometry conversion flags *****// 
	if(strcmp(argv[i],"-nc")==0){//No Nurbs Conversion -> only for primitive Shapes or Visualisation
	  fbdConv=false;
	  nConvert = false;
	}  
	if(strcmp(argv[i],"-pln")==0){//deactivate planes
	  usePln = false;
	}
	if(strcmp(argv[i],"-cyl")==0){//deactivate cylinders
	  useCyl = false;
	}
	if(strcmp(argv[i],"-con")==0){//deactivate cones
	  useCon = false;
	}
	if(strcmp(argv[i],"-sph")==0){//deactivate spheres
	  useSph = false;
	}
	if(strcmp(argv[i],"-tor")==0){//deactivate torodial shapes
	  useTor = false;
	}
	
	//*******  other flags   *********//
	if(strcmp(argv[i],"-v")==0){//Visualise Topology Tree
	  topoVis = true;
	}
	if(strcmp(argv[i],"-nch")==0){//don' check whether NURBS are clamped -> speed up import
	  checkNURBS = false;
	}
	if(strcmp(argv[i],"-tolM")==0){//change tolerance for merging points
	  cout<<"using tolerance "<< atof(argv[i+1])<<" for merging points"<<endl;
	  tolMergPoints = atof(argv[i+1]);
	}
	if(strcmp(argv[i],"-nal")==0){//deactivate aliasing
	  aliasing = false;
	}
	if(strcmp(argv[i],"-ex")==0){//Export Healed and Converted Geometry to Step
	  save = true;
	}    
	if(strcmp(argv[i],"-xde")==0){//Use Extended Data Exchange to import CAD with colors
	  useXDE = true;
	}  
    }
    // load the cad file and retrieve the geometry as a TopoDS_Shape
    if(!loadStep(&result,&loadName[0])) {cout<<"Error while loading CAD-File... Exit"<<endl; return 0;}
    
    // perform the shape healing and correction routine on the loaded shape
    if(fbdConv) healFace(&result,splitClose,splitConti);
    
    initTopology(&result);//generate Topology Objects and store them in vector lists  
    linkTopoTree();//link the Topology Objects in the vector lists
    
    if(topoVis) plotTopology();//visualise the topology tree
    
    if(nConvert){
      convert2Nurbs();//convert the underlying geometry to NURBS 
    }
    if(fbdConv){ 
      drawTopology("result.fbd");//write the geometry to a fbd-File using cgx commands
    }
    if(save) saveStep(&result,"export.stp");// export the resulting geometry as a STEP file
    
    cout<<"Ready Exit"<<endl;
  }

  output.close();
  return 0;
}



