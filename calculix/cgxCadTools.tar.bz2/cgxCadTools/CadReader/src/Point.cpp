#include <CadReader.hxx>
#include <Point.hxx>

#define MAX(a, b) ((a) < (b) ? (b) : (a))
#define MIN(a, b) ((a) > (b) ? (b) : (a))
//Tolerance for merging Points

/****************************************/
//Class Point
  Point :: Point(double xi, double yi, double zi)
  {
    //determine a reference size of the model geometry
    if(refLength == -1)
    {
      globalMax[0] = xi; 
      globalMin[0] = xi; 
      globalMax[1] = yi; 
      globalMin[1] = yi; 
      globalMax[2] = zi; 
      globalMin[2] = zi; 
    }
    else
    {
      globalMax[0] = MAX(xi,globalMax[0]); 
      globalMax[1] = MAX(yi,globalMax[1]); 
      globalMax[2] = MAX(zi,globalMax[2]); 
      globalMin[0] = MIN(xi,globalMin[0]); 
      globalMin[1] = MIN(yi,globalMin[1]); 
      globalMin[2] = MIN(zi,globalMin[2]); 
    }  
    refLength = MAX((globalMax[0]-globalMin[0]),MAX(globalMax[1]-globalMin[1],globalMax[2]-globalMin[2]));
    x=xi; y=yi;z=zi;
  };
  
  int Point :: write2fbd()
  {
    int counter=0;
    for(std::vector<Point*>::iterator pi = (pointList).begin();pi != (pointList).end();++pi)
    {
      //check if a point already exists at this position (or closer than tolMergPoints)
      if((fabs((*pi)->x - x)+fabs((*pi)->y - y)+fabs((*pi)->z - z)) < tolMergPoints)
      { 
	return counter;	
      }
      counter++;
    } 
    pointList.push_back(this);  
    output<<"pnt !p"<< counter<<" "<<x<<" "<<y<<" "<<z<<endl;
    return  counter;  
  }

/****************************************/