#ifndef vertex_hxx
#define vertex_hxx

using namespace std;

/****************************************/
//Class Vertex;
class Vertex : public Topology
{
  public:
    Vertex(TopoDS_Vertex v,bool f);
    
    void linkSubElements();
    
    void plotTopoTree(stringstream & str);
    
    TopoDS_Vertex getVertex();
  
  private: 
    TopoDS_Vertex myVertex;
};
/****************************************/

#endif