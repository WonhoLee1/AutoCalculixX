#ifdef globalDefine
  #define EXTERN
#else
  #define EXTERN extern
#endif

//OpenCascade libraries 
#include <STEPControl_Reader.hxx> 
#include <STEPControl_Writer.hxx>
#include <IGESControl_Reader.hxx>   

#include <TColStd_HSequenceOfTransient.hxx>     
 
#include <BRep_Builder.hxx>
#include <TopoDS_Builder.hxx>
#include <TopoDS.hxx>
#include <TopoDS_Shape.hxx> 

#include <BRepBuilderAPI_NurbsConvert.hxx>
#include <BRepOffsetAPI_Sewing.hxx>
#include <BRepBuilderAPI_Sewing.hxx>

#include <TopExp_Explorer.hxx>
#include <TopExp.hxx>
#include <TopTools_IndexedMapOfShape.hxx>
#include <BRepTools.hxx>
#include <BRep_Tool.hxx>
#include <Standard_values.h>
#include <Standard_math.hxx>
#include <Standard_TypeDef.hxx>

#include <Geom_Curve.hxx>
#include <Geom_BSplineCurve.hxx>

#include <Geom_BSplineSurface.hxx>
#include <GeomConvert.hxx>

#include <TColStd_Array1OfReal.hxx>
#include <Standard_Transient.hxx>
#include <Standard.hxx>

#include <ShapeUpgrade.hxx>
#include <ShapeCustom.hxx>
#include <ShapeUpgrade_ShapeDivide.hxx>
#include <ShapeUpgrade_FaceDivide.hxx> 
#include <ShapeUpgrade_WireDivide.hxx> 
#include <TopoDS_Shape.hxx> 
#include <ShapeUpgrade_ClosedFaceDivide.hxx>
#include <ShapeUpgrade_ShapeDivideClosed.hxx>
#include <ShapeBuild_ReShape.hxx>
#include <ShapeUpgrade_ShapeDivideArea.hxx>

#include <ShapeAnalysis_Edge.hxx>
#include <ShapeAnalysis_ShapeTolerance.hxx>
#include <ShapeAnalysis_ShapeContents.hxx>
#include <ShapeAnalysis_CheckSmallFace.hxx>
#include <ShapeAnalysis_DataMapOfShapeListOfReal.hxx>
#include <ShapeAnalysis_Surface.hxx>

#include <ShapeUpgrade_ShapeDivideContinuity.hxx>

#include <BRepAdaptor_Curve.hxx>
#include <GCPnts_AbscissaPoint.hxx>
#include <Adaptor3d_Curve.hxx>
#include <ShapeAnalysis.hxx>
#include <GProp_GProps.hxx>
#include <BRepGProp.hxx>
#include <GeomAdaptor.hxx>
#include <Standard_PrimitiveTypes.hxx>

#include <ShapeFix.hxx>
#include <ShapeFix_Shape.hxx>
#include <ShapeFix_Wireframe.hxx>
#include <ShapeFix_Edge.hxx>

#include <gp.hxx>
#include <gp_Pnt.hxx>

#include <GeomAPI_ProjectPointOnCurve.hxx>

//XDE related includes
#include <STEPCAFControl_Reader.hxx>
#include <IGESCAFControl_Reader.hxx>
#include <XCAFApp_Application.hxx>
#include <XCAFDoc_DocumentTool.hxx>
#include <XCAFDoc_ShapeTool.hxx>
#include <TDocStd_Document.hxx>
#include <Quantity_Color.hxx>
#include <XCAFDoc_ColorTool.hxx>

//C++ Includes
#include <vector>
#include <sstream>
#include <string>
//Geometrical Includes
#include <Point.hxx>
#include <Curve.hxx>
#include <Surface.hxx>

//Topological Includes
//Parent Class
#include <Topology.hxx>
//Child Classes
#include <Vertex.hxx>
#include <Edge.hxx>
#include <Wire.hxx>
#include <Face.hxx>
#include <Shell.hxx>
#include <Solid.hxx>
#include <CompSolid.hxx>
#include <Compound.hxx>

using namespace std;

EXTERN vector<Compound*> freeCompound;
EXTERN vector<CompSolid*> freeCompSolid;
EXTERN vector<Solid*> freeSolid;
EXTERN vector<Shell*> freeShell;
EXTERN vector<Face*> freeFace;
EXTERN vector<Wire*> freeWire;
EXTERN vector<Edge*> freeEdge;
EXTERN vector<Point*> pointList;

EXTERN vector<Quantity_Color*> faceColorList; 
EXTERN vector<Quantity_Color*> solidColorList; 

EXTERN ofstream output;

EXTERN Handle(TDocStd_Document) myDoc;

EXTERN bool usePln,useCyl,useCon,useSph,useTor;
EXTERN bool aliasing, checkNURBS, useXDE;

EXTERN double  tolMergPoints, refLength, globalMax[3], globalMin[3];

void initTopology(TopoDS_Shape *shape);
void linkTopoTree();
void plotTopology();
void drawTopology(const char * name);

void saveStep(TopoDS_Shape * shape,const char * name);
bool loadStep(TopoDS_Shape *shape, char * name);
bool validNurs(Handle(Geom_BSplineSurface) nSurf);
bool healFace(TopoDS_Shape *shape,bool splitClose,bool splitConti);
void convert2Nurbs();

void startScreen();
void menuLoad(TopoDS_Shape * result);
void menuConvert(TopoDS_Shape * result);
void menuTopology(TopoDS_Shape * result);
void menuSave(TopoDS_Shape * result);

