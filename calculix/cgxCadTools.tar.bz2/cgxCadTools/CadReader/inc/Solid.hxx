#ifndef Solid_hxx
#define Solid_hxx

using namespace std;

/****************************************/
//Class Solid;
class Solid : public Topology
{
  public:
    Solid(TopoDS_Solid s,int n,Quantity_Color *col);
    
    void linkSubElements();
    
    std::vector<Shell*> * getShellList();
    
    void plotTopoTree(stringstream & str);
    
    void write2fbd();
    
    TopoDS_Solid getSolid();
    
    void setColor(Quantity_Color c);
    
    void setColor(Quantity_Color * col);
    
    Quantity_Color * getColor();
    
  private:
    std::vector<Shell*> shellList;
    TopoDS_Solid mySolid;
    Quantity_Color myColor;
};
/****************************************/

#endif