#ifndef Shell_hxx
#define Shell_hxx

using namespace std;

/****************************************/
//Class Shell;
class Shell : public Topology
{
  public:
    Shell(TopoDS_Shell s,int n);
    
    void linkSubElements();
    
    std::vector<Face*> * getFaceList();
    
    void plotTopoTree(stringstream & str);
    
    void write2fbd();
         
    TopoDS_Shell getShell();
    
  private:
    std::vector<Face*> faceList;  
    TopoDS_Shell myShell;
};
/****************************************/

#endif