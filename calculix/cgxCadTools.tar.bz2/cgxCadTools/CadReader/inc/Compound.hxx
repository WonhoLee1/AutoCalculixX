#ifndef Compound_hxx
#define Compound_hxx

using namespace std;

/****************************************/
//Class Compound 
class Compound : public Topology
{
  public:
    Compound(TopoDS_Compound c,int n);
    
    void linkSubElements();
    
    std::vector<CompSolid*> * getcompSolidList();
    
    void plotTopoTree(stringstream & str);
    
  private:
    vector<CompSolid*> compSolidList;
    TopoDS_Compound myCompound;
};
/****************************************/

#endif