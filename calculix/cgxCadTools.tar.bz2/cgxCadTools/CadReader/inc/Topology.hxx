#ifndef Topology_hxx
#define Topology_hxx

/*********** Class Topology ****************/
/*************** Abstract ******************/
class Topology
{
  public: 
    virtual void linkSubElements() = 0;
    
    virtual void plotTopoTree(stringstream & str) = 0;
    
     int * getNumber();
    
     bool * getFree();
     
     void setFree(bool f);
     
  protected:
    int number;
    int subElements;
    bool free;
};

/*********** Class Topology END*************/

#endif
