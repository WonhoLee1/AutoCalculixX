#ifndef Point_hxx
#define Point_hxx

/****************************************/
//Class Point;
class Point
{
  public:
    Point(double xi, double yi, double zi);
    
    int write2fbd();
    
  private: 
    double x,y,z;
    
};

/****************************************/
#endif