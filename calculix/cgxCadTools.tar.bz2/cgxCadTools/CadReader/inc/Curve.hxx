#ifndef Curve_hxx
#define Curve_hxx

#include <Geom_Circle.hxx>
#include <Geom_Ellipse.hxx>
#include <Geom_Hyperbola.hxx>
#include <Geom_Line.hxx>
#include <Geom_Parabola.hxx>
#include <Geom_BezierCurve.hxx>
#include <Geom_TrimmedCurve.hxx>
#include <Geom_OffsetCurve.hxx>

using namespace std;
/****************************************/
//Class Curve
class Curve
{
  public:
    Curve(Handle(Geom_Curve) s,int n);
    
    int write2fbd(Handle(Geom_BSplineCurve) nCurve, short split);
    
    int drawCurve(bool * split);
    
    void plotCurveType(stringstream &str);
    
    void setCurve(Handle(Geom_Curve) c);
    
  private:
    Handle(Geom_Curve) curve;
    int number;
    
};

/****************************************/

#endif 
