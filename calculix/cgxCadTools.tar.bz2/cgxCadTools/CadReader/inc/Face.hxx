#ifndef Face_hxx
#define Face_hxx

/****************************************/
//Class Face;
class Face : public Topology
{
  public:
    Face(TopoDS_Face face,int n, Quantity_Color *col);
    
    void linkSubElements();
    
    void write2fbd();
    
    std::vector<Wire*> * getWireList();
    
    void plotTopoTree(stringstream & str);
    
    TopoDS_Face getFace();
    
    bool * getStatus();
    
    void convertNurbs();
    
    Surface * getSurface();
    
    void setColor(Quantity_Color * col);
    
    Quantity_Color * getColor();
    
    void writeColor2fbd(Quantity_Color *col,stringstream & str);
    
  private:
    std::vector<Wire*> wireList;  
    TopoDS_Face myFace;
    Surface * mySurface;
    bool status;
    bool converted;
    Quantity_Color myColor;
};
/****************************************/

#endif