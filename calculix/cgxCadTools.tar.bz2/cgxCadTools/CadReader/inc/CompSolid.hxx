#ifndef CompSolid_hxx
#define CompSolid_hxx

using namespace std;

/****************************************/
//Class CompSolid;
class CompSolid : public Topology
{
  public:
    CompSolid(TopoDS_CompSolid c,int n);
    
    void linkSubElements();
    
    std::vector<Solid*> * getSolidList();
    
    void plotTopoTree(stringstream & str);
    
    TopoDS_CompSolid getCompSolid();  
    
  private:
    std::vector<Solid*> solidList;  
    TopoDS_CompSolid myCompSolid;
};
/****************************************/

#endif