#ifndef Edge_hxx
#define Edge_hxx

using namespace std;

/****************************************/
//Class Edge;
class Edge : public Topology
{
  public:
    Edge(TopoDS_Edge e,int n,bool s);
    
    void linkSubElements();
    
    vector<Vertex*> * getVertexList();
    
    void write2fbd();
    
    void plotTopoTree(stringstream & str);
    
    TopoDS_Edge getEdge();
    
    bool * getSplit();
    
    bool * getStatus();   
    
    void setFree(bool f);
 
    bool getFree();
    
    void setSeamEdge(bool s);
    
    bool getSeamEdge();
    
    void convertNurbs();
    
  private:
    std::vector<Vertex*> vertexList;  
    TopoDS_Edge myEdge;
    Curve* myCurve;
    bool split;
    bool status;
    bool seamEdge;
    Standard_Real c_start,c_end;
};
/****************************************/

#endif