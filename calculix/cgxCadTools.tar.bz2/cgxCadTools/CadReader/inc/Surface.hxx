#ifndef Surface_hxx
#define Surface_hxx

#include <gp_Pln.hxx>
#include <gp_Cylinder.hxx>
#include <gp_Cone.hxx>
#include <gp_Sphere.hxx>
#include <gp_Torus.hxx>
#include <gp_Ax1.hxx>

#include <Geom_ConicalSurface.hxx>
#include <Geom_CylindricalSurface.hxx>
#include <Geom_SphericalSurface.hxx>
#include <Geom_ToroidalSurface.hxx>
#include <Geom_SurfaceOfLinearExtrusion.hxx>
#include <Geom_SurfaceOfRevolution.hxx>
#include <Geom_BezierSurface.hxx>
#include <Geom_RectangularTrimmedSurface.hxx>
#include <Geom_Plane.hxx>

using namespace std;
/****************************************/
//Class Surface
class Surface
{
  public:
    Surface( Handle(Geom_Surface) s,int n);
    
    void drawSurface();
    
    void plotSurfaceType(stringstream &str,bool nurbs);
    
    void setNurbsSurface(Handle(Geom_Surface) nSurf);
    
    void nurbsSurface2fbd(Handle(Geom_BSplineSurface) nSurf,int *number);
    
  private:
    Handle(Geom_Surface) surf;
    Handle(Geom_Surface) surfNurbs;
    int number;   
};

/****************************************/

#endif