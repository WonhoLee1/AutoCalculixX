#ifndef Wire_hxx
#define Wire_hxx

using namespace std;

/****************************************/
//Class Wire;
class Wire : public Topology
{
  public:
    Wire(TopoDS_Wire w,int n);
    
    void linkSubElements();
    
    std::vector<Edge*> * getEdgeList();
    
    void plotTopoTree(stringstream & str);
    
    TopoDS_Wire getWire();
        
    int * getSubElements();
    
    std::vector<bool> * edgeReversedList();
    
  private:
    std::vector<Edge*> edgeList;  
    std::vector<bool> edgeReversed;
    TopoDS_Wire myWire;
};
/****************************************/
#endif